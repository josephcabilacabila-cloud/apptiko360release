
(function() {
  const months = ["Jan", "Fév", "Mar", "Avr", "Mai", "Juin", "Juil", "Août", "Sep", "Oct", "Nov", "Déc"];
  const currentYear = new Date().getFullYear();

  // --- CSS intégré (visible sur mobile et PC) ---
  const css = `
    .month-btns-container {
      display: flex;
      flex-wrap: wrap;
      gap: 6px;
      margin-bottom: 8px;
    }
    .btn-month-toggle {
      flex: 1 1 calc(25% - 6px);
      padding: 10px;
      font-size: 0.9rem;
      border-radius: 8px;
      border: none;
      cursor: pointer;
      background-color: #3498db;
      color: white;
      transition: transform 0.15s ease, background 0.3s ease;
    }
    .btn-month-toggle:hover { background-color: #2980b9; transform: translateY(-2px); }
    /* Modale flottante */
    .month-modal-overlay {
      position: fixed;
      inset: 0;
      background: rgba(0,0,0,0.4);
      display: flex;
      align-items: center;
      justify-content: center;
      z-index: 99999;
      animation: fadeIn 0.2s ease forwards;
    }
    .month-modal {
      background: white;
      border-radius: 12px;
      padding: 16px;
      width: 280px;
      text-align: center;
      box-shadow: 0 8px 20px rgba(0,0,0,0.25);
      animation: scaleIn 0.25s ease forwards;
      font-family: sans-serif;
    }
    .month-modal h3 { margin-top: 0; color: #333; }
    .month-modal button {
      margin: 6px 0;
      padding: 10px;
      font-size: 0.9rem;
      border-radius: 8px;
      border: none;
      cursor: pointer;
      transition: opacity 0.2s ease;
    }
    .btn-cocher { background: #28a745; color: white; }
    .btn-decocher { background: #dc3545; color: white; }
    .btn-close { background: #ccc; color: #333; width: 39px;}
    .month-modal button:hover { opacity: 0.85; }
    @keyframes fadeIn { from {opacity:0} to {opacity:1} }
    @keyframes scaleIn { from {transform: scale(0.9)} to {transform: scale(1)} }
  `;
  const styleTag = document.createElement("style");
  styleTag.textContent = css;
  document.head.appendChild(styleTag);

  function formatDate(year, month, day) {
    return `${year}-${String(month).padStart(2,'0')}-${String(day).padStart(2,'0')}`;
  }

  // Met à jour visuellement une case
  function updateCellVisual(td, isPaid) {
    if (!td) return;
    td.textContent = isPaid ? "✔" : "";
    td.classList.toggle("paid", isPaid);
    td.classList.toggle("unpaid", !isPaid);
  }

  // Action coche/décocher
  function toggleMonth(participantIndex, monthIndex, action, tableEl) {
    const payments = JSON.parse(localStorage.getItem("tontine_payments") || "{}");
    payments[participantIndex] = payments[participantIndex] || {};
    let monthNum = monthIndex + 1;
    let changed = false;

    tableEl.querySelectorAll("tbody tr").forEach((tr) => {
      const dayCell = parseInt(tr.querySelector("th").textContent, 10);
      if (!isNaN(dayCell)) {
        const dateStr = formatDate(currentYear, monthNum, dayCell);
        if (action === "check" && !payments[participantIndex][dateStr]) {
          payments[participantIndex][dateStr] = true;
          updateCellVisual(tr.cells[monthIndex + 1], true);
          changed = true;
        }
        if (action === "uncheck" && payments[participantIndex][dateStr]) {
          delete payments[participantIndex][dateStr];
          updateCellVisual(tr.cells[monthIndex + 1], false);
          changed = true;
        }
      }
    });

    if (changed) {
      localStorage.setItem("tontine_payments", JSON.stringify(payments));
    }
  }

  // Ouvre la modale
  function openMonthModal(monthName, participantIndex, monthIndex, tableEl) {
    const overlay = document.createElement("div");
    overlay.className = "month-modal-overlay";

    const modal = document.createElement("div");
    modal.className = "month-modal";
    modal.innerHTML = `
      <h3>${monthName} - Action</h3>
      <button class="btn-cocher">✅ Cocher tout le mois</button>
      <button class="btn-decocher"> Vider tout le mois</button>
      <button class="btn-close">Fermer</button>
    `;

    modal.querySelector(".btn-cocher").onclick = () => {
      toggleMonth(participantIndex, monthIndex, "check", tableEl);
      document.body.removeChild(overlay);
    };
    modal.querySelector(".btn-decocher").onclick = () => {
      toggleMonth(participantIndex, monthIndex, "uncheck", tableEl);
      document.body.removeChild(overlay);
    };
    modal.querySelector(".btn-close").onclick = () => {
      document.body.removeChild(overlay);
    };

    overlay.appendChild(modal);
    overlay.addEventListener("click", (e) => {
      if (e.target === overlay) document.body.removeChild(overlay);
    });

    document.body.appendChild(overlay);
  }

  // Ajoute les boutons mois
  function addMonthButtons(wrapper, participantIndex, tableEl) {
    if (wrapper.querySelector(".month-btns-container")) return;

    const btnContainer = document.createElement("div");
    btnContainer.className = "month-btns-container";

    months.forEach((m, monthIndex) => {
      const btn = document.createElement("button");
      btn.textContent = m;
      btn.className = "btn-month-toggle";
      btn.addEventListener("click", () => openMonthModal(m, participantIndex, monthIndex, tableEl));
      btnContainer.appendChild(btn);
    });

    wrapper.insertBefore(btnContainer, wrapper.firstChild);
  }

  // Observe le DOM
  const observer = new MutationObserver(() => {
    document.querySelectorAll("#participants-container .person-item").forEach((personEl, index) => {
      const wrapper = personEl.querySelector(".table-wrapper");
      const tableEl = personEl.querySelector("table");
      if (wrapper && tableEl) {
        addMonthButtons(wrapper, index, tableEl);
      }
    });
  });

  observer.observe(document.getElementById("participants-container"), { childList: true, subtree: true });
})();
