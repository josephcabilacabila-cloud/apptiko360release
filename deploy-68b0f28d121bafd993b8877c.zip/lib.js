// Chargement dynamique des libs externes : Chart.js + jsPDF + jsPDF autotable
(() => {
  const loadScript = (src) => new Promise((res, rej) => {
    if (document.querySelector(`script[src="${src}"]`)) return res();
    const s = document.createElement('script');
    s.src = src;
    s.onload = res;
    s.onerror = rej;
    document.head.appendChild(s);
  });

  async function main() {
    await loadScript('https://cdn.jsdelivr.net/npm/chart.js');
    await loadScript('https://cdnjs.cloudflare.com/ajax/libs/jspdf/2.5.1/jspdf.umd.min.js');
    await loadScript('https://cdnjs.cloudflare.com/ajax/libs/jspdf-autotable/3.5.28/jspdf.plugin.autotable.min.js');

    const { jsPDF } = window.jspdf;

   // Création du bouton icône
    const btn = document.createElement('button');
    btn.innerHTML = '<i class="fas fa-chart-line"></i>';
    Object.assign(btn.style, {
      position: 'fixed',
      top: '28px',
      left: '25%',
      transform: 'translateX(-50%)',
      background: 'linear-gradient(135deg, #4caf50, #81c784)',
      color: 'white',
      border: 'none',
      borderRadius: '50%',
      width: '60px',
      height: '50px',
      fontSize: '24px',
      cursor: 'pointer',
      zIndex: '9999',
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center',
      boxShadow: '0 6px 20px rgba(0,0,0,0.3)',
      transition: 'all 0.3s ease',
    });
    btn.addEventListener('mouseover', () => {
      btn.style.transform = 'translateX(-50%) scale(1.2)';
      btn.style.boxShadow = '0 0 20px 4px rgba(76,175,80,0.6)';
    });
    btn.addEventListener('mouseout', () => {
      btn.style.transform = 'translateX(-50%) scale(1)';
      btn.style.boxShadow = '0 6px 20px rgba(0,0,0,0.3)';
    });
    document.body.appendChild(btn);
    // Overlay modal
    const overlay = document.createElement('div');
    Object.assign(overlay.style, {
      position: 'fixed', inset: '0',
      backgroundColor: 'rgba(0,0,0,0.6)',
      display: 'none', justifyContent: 'center',
      alignItems: 'center', zIndex: '10000',
      padding: '20px',
      overflowY: 'auto',
      fontFamily: "'Segoe UI', Tahoma, Geneva, Verdana, sans-serif"
    });

    const modal = document.createElement('div');
    Object.assign(modal.style, {
      background: '#fff',
      borderRadius: '12px',
      width: '95%',
      maxWidth: '900px',
      maxHeight: '90vh',
      overflowY: 'auto',
      padding: '30px',
      boxShadow: '0 10px 40px rgba(0,0,0,0.25)',
      color: '#1e293b',
      fontSize: '15px',
      lineHeight: '1.4',
    });

    const closeBtn = document.createElement('button');
    closeBtn.textContent = 'Fermer ✖';
    Object.assign(closeBtn.style, {
      marginTop: '25px',
      backgroundColor: '#ef4444',
      color: '#fff',
      border: 'none',
      borderRadius: '6px',
      padding: '10px 20px',
      cursor: 'pointer',
      fontWeight: '600',
      float: 'right',
      userSelect: 'none',
      transition: 'background-color 0.3s'
    });
    closeBtn.onmouseover = () => closeBtn.style.backgroundColor = '#b91c1c';
    closeBtn.onmouseout = () => closeBtn.style.backgroundColor = '#ef4444';

    overlay.appendChild(modal);
    document.body.appendChild(overlay);

    closeBtn.onclick = () => {
      overlay.style.display = 'none';
      // Nettoyer canvas pour éviter doublons
      const canvases = modal.querySelectorAll('canvas');
      canvases.forEach(c => c.remove());
    };
    overlay.onclick = e => {
      if (e.target === overlay) {
        overlay.style.display = 'none';
        const canvases = modal.querySelectorAll('canvas');
        canvases.forEach(c => c.remove());
      }
    };

    function afficherStats() {
      const participants = JSON.parse(localStorage.getItem('tontine_participants') || '[]');
      const paiements = JSON.parse(localStorage.getItem('tontine_payments') || '{}');
      const year = new Date().getFullYear();

      if (participants.length === 0) {
        modal.innerHTML = `<p style="color:#dc2626;font-weight:700;">Aucun participant enregistré.</p>`;
        modal.appendChild(closeBtn);
        overlay.style.display = 'flex';
        return;
      }

      let totalEntreprise = 0;
      let totalTous = 0;
      let totalMembres = 0;

      const labels = [];
      const totalPayes = [];
      const total31s = [];
      const totalMembresArr = [];

      let sommeCotisation = 0;

      const tableRows = [];

     // Dans la boucle participants.forEach(...)
participants.forEach((p, i) => {
  const nom = `${p.firstname} ${p.lastname}`;
  const cotisation = parseInt(p.cotisation, 10) || 0;
  sommeCotisation += cotisation;

  const payDates = Object.entries(paiements[i] || {})
    .filter(([date, ok]) => ok)
    .map(([date]) => date)
    .sort((a, b) => new Date(a) - new Date(b)); // tri pour repérer le dernier paiement

  const totalPerso = payDates.length * cotisation;

  // Jours 31
  let total31 = payDates.filter(d => d.endsWith('-31')).length * cotisation;

  // Ajouter le dernier jour payé même si ce n’est pas un 31
  if (payDates.length > 0) {
    const dernierPaiement = payDates[payDates.length - 1];
    if (!dernierPaiement.endsWith('-31')) {
      total31 += cotisation; // ajoute la dernière cotisation à l'entreprise
    }
  }

  const totalMembre = totalPerso - total31;

  totalTous += totalPerso;
  totalEntreprise += total31;
  totalMembres += totalMembre;

  labels.push(nom);
  totalPayes.push(totalPerso);
  total31s.push(total31);
  totalMembresArr.push(totalMembre);

  tableRows.push({
    nom, cotisation,
    totalPerso, total31,
    totalMembre,
    pourcentageEntreprise: totalPerso === 0 ? 0 : (total31 / totalPerso) * 100,
    pourcentageMembre: totalPerso === 0 ? 0 : (totalMembre / totalPerso) * 100,
  });
});


      const moyenneCotisation = sommeCotisation / participants.length;
      const moyennePaiement = totalTous / participants.length;
      const moyenneEntreprise = totalEntreprise / participants.length;
      const moyenneMembre = totalMembres / participants.length;

      // Tri décroissant par total payé
      tableRows.sort((a,b) => b.totalPerso - a.totalPerso);

      modal.innerHTML = `
        <h2 style="margin-top:0; font-weight:900; font-size:1.8em; color:#1e293b;">
          📊 Rapport global tontine - Année ${year}
        </h2>

        <section style="margin-bottom:30px;">
          <strong>Détails globaux :</strong>
          <ul style="list-style:none; padding-left:0; font-size:1em; margin-top:8px;">
            <li><b>Participants :</b> ${participants.length}</li>
            <li><b>Somme des cotisations :</b> ${sommeCotisation.toLocaleString()} FCFA</li>
            <li><b>Total payé (tous carnets) :</b> ${totalTous.toLocaleString()} FCFA</li>
            <li><b>Total entreprise (31 du mois) :</b> ${totalEntreprise.toLocaleString()} FCFA</li>
            <li><b>Total membre :</b> ${totalMembres.toLocaleString()} FCFA</li>
            <li><b>Moyenne cotisation :</b> ${moyenneCotisation.toFixed(2)} FCFA</li>
            <li><b>Moyenne total payé :</b> ${moyennePaiement.toFixed(2)} FCFA</li>
            <li><b>Moyenne total entreprise :</b> ${moyenneEntreprise.toFixed(2)} FCFA</li>
            <li><b>Moyenne total membre :</b> ${moyenneMembre.toFixed(2)} FCFA</li>
          </ul>
        </section>

        <section style="display:flex; gap:20px; flex-wrap:wrap; margin-bottom:40px;">
          <canvas id="barChart" style="flex:1 1 300px; height:320px;"></canvas>
          <canvas id="pieChart" style="flex:1 1 300px; height:320px;"></canvas>
          <canvas id="lineChart" style="flex:1 1 300px; height:320px;"></canvas>
        </section>

        <section>
          <h3 style="margin-bottom:12px; color:#334155;">Détail par participant</h3>
          <div style="overflow-x:auto;">
          <table style="width:100%; border-collapse: collapse; font-size:14px;">
            <thead style="background:#e0e7ff; color:#1e293b;">
              <tr>
                <th style="border:1px solid #cbd5e1; padding:8px; text-align:left;">Participant</th>
                <th style="border:1px solid #cbd5e1; padding:8px; text-align:right;">Cotisation</th>
                <th style="border:1px solid #cbd5e1; padding:8px; text-align:right;">Total payé</th>
                <th style="border:1px solid #cbd5e1; padding:8px; text-align:right;">Total 31</th>
                <th style="border:1px solid #cbd5e1; padding:8px; text-align:right;">Total membre</th>
                <th style="border:1px solid #cbd5e1; padding:8px; text-align:right;">% entreprise</th>
                <th style="border:1px solid #cbd5e1; padding:8px; text-align:right;">% membre</th>
              </tr>
            </thead>
            <tbody>
              ${tableRows.map(r => `
                <tr>
                  <td style="border:1px solid #cbd5e1; padding:6px;">${r.nom}</td>
                  <td style="border:1px solid #cbd5e1; padding:6px; text-align:right;">${r.cotisation.toLocaleString()} FCFA</td>
                  <td style="border:1px solid #cbd5e1; padding:6px; text-align:right;">${r.totalPerso.toLocaleString()} FCFA</td>
                  <td style="border:1px solid #cbd5e1; padding:6px; text-align:right;">${r.total31.toLocaleString()} FCFA</td>
                  <td style="border:1px solid #cbd5e1; padding:6px; text-align:right;">${r.totalMembre.toLocaleString()} FCFA</td>
                  <td style="border:1px solid #cbd5e1; padding:6px; text-align:right;">${r.pourcentageEntreprise.toFixed(1)}%</td>
                  <td style="border:1px solid #cbd5e1; padding:6px; text-align:right;">${r.pourcentageMembre.toFixed(1)}%</td>
                </tr>
              `).join('')}
            </tbody>
          </table>
          </div>
        </section>

        <section style="margin-top:35px; text-align:center; display:flex; gap:20px; justify-content:center;">
          <button id="btnExportCSV" style="
            background:#2563eb; color:#fff; border:none; border-radius:8px; padding:12px 30px;
            font-weight:700; cursor:pointer; font-size:16px;
            box-shadow: 0 6px 15px rgba(37, 99, 235, 0.5);
            user-select:none;
          ">📥 Exporter rapport CSV</button>

          <button id="btnExportPDF" style="
            background:#10b981; color:#fff; border:none; border-radius:8px; padding:12px 30px;
            font-weight:700; cursor:pointer; font-size:16px;
            box-shadow: 0 6px 15px rgba(16, 185, 129, 0.5);
            user-select:none;
          ">📄 Exporter rapport PDF</button>
        </section>
      `;

      modal.appendChild(closeBtn);
      overlay.style.display = 'flex';

      // Charts
      const barCtx = document.getElementById('barChart').getContext('2d');
      new Chart(barCtx, {
        type: 'bar',
        data: { labels, datasets: [{ label: 'Total payé', data: totalPayes, backgroundColor: '#2563eb' }] },
        options: {
          responsive: true,
          plugins: { legend: { display: false }, tooltip: { mode: 'index', intersect: false } },
          scales: { y: { beginAtZero: true, ticks: { stepSize: 5000 } }, x: { ticks: { maxRotation: 90, minRotation: 30 } } }
        }
      });

      const pieCtx = document.getElementById('pieChart').getContext('2d');
      new Chart(pieCtx, {
        type: 'pie',
        data: {
          labels: ['Entreprise (31)', 'Membres (autres jours)'],
          datasets: [{ data: [totalEntreprise, totalMembres], backgroundColor: ['#16a34a', '#2563eb'] }]
        },
        options: { responsive: true, plugins: { legend: { position: 'bottom' } } }
      });

      // Line chart (simulé par mois)
      const moisLabels = ['Jan', 'Fév', 'Mar', 'Avr', 'Mai', 'Juin', 'Juil', 'Août', 'Sep', 'Oct', 'Nov', 'Déc'];
      let monthlyEntreprise = new Array(12).fill(0);
      let monthlyMembres = new Array(12).fill(0);

      participants.forEach((p, i) => {
        const cotisation = parseInt(p.cotisation, 10) || 0;
        const payDates = Object.entries(paiements[i] || {}).filter(([date, ok]) => ok).map(([date]) => date);
        payDates.forEach(d => {
          const monthIdx = new Date(d).getMonth();
          if (d.endsWith('-31')) monthlyEntreprise[monthIdx] += cotisation;
          else monthlyMembres[monthIdx] += cotisation;
        });
      });

      const lineCtx = document.getElementById('lineChart').getContext('2d');
      new Chart(lineCtx, {
        type: 'line',
        data: {
          labels: moisLabels,
          datasets: [
            {
              label: 'Entreprise (31)',
              data: monthlyEntreprise,
              borderColor: '#16a34a',
              backgroundColor: 'rgba(22,163,74,0.2)',
              fill: true,
              tension: 0.3,
              pointRadius: 4
            },
            {
              label: 'Membres (autres jours)',
              data: monthlyMembres,
              borderColor: '#2563eb',
              backgroundColor: 'rgba(37,99,235,0.2)',
              fill: true,
              tension: 0.3,
              pointRadius: 4
            }
          ]
        },
        options: {
          responsive: true,
          interaction: { mode: 'nearest', intersect: false },
          scales: { y: { beginAtZero: true, ticks: { stepSize: 5000 } } }
        }
      });

      // Export CSV
      const btnExportCSV = document.getElementById('btnExportCSV');
      btnExportCSV.onclick = () => {
        let csvContent = 'Participant,Cotisation,Total payé,Total 31,Total membre,% entreprise,% membre\n';
        tableRows.forEach(r => {
          csvContent += `"${r.nom}",${r.cotisation},${r.totalPerso},${r.total31},${r.totalMembre},${r.pourcentageEntreprise.toFixed(1)}%,${r.pourcentageMembre.toFixed(1)}%\n`;
        });

        const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
        const link = document.createElement('a');
        link.href = URL.createObjectURL(blob);
        link.setAttribute('download', `rapport_tontine_${year}.csv`);
        document.body.appendChild(link);
        link.click();
        document.body.removeChild(link);
      };

      // Export PDF
    // Export PDF
const btnExportPDF = document.getElementById('btnExportPDF');
btnExportPDF.onclick = async () => {
  const doc = new jsPDF();

  const today = new Date().toLocaleDateString();

 

  // Titre + date
  doc.setFontSize(18);
  doc.setTextColor('#1e293b');
  doc.text(`Rapport global tontine - Année ${year}`, 14, 20);
  doc.setFontSize(10);
  doc.setTextColor('#555');
 
  doc.text(`Généré le ${today}`, 14, 26);

  // Détails globaux
  doc.setFontSize(12);
  doc.setTextColor('#334155');
  const details = [
    `Participants: ${participants.length}`,
    `Somme des cotisations: ${sommeCotisation.toLocaleString()} FCFA`,
    `Total payé (tous carnets): ${totalTous.toLocaleString()} FCFA`,
    `Total entreprise (31 du mois): ${totalEntreprise.toLocaleString()} FCFA`,
    `Total membre: ${totalMembres.toLocaleString()} FCFA`,
    `Moyenne cotisation: ${moyenneCotisation.toFixed(2)} FCFA`,
    `Moyenne total payé: ${moyennePaiement.toFixed(2)} FCFA`,
    `Moyenne total entreprise: ${moyenneEntreprise.toFixed(2)} FCFA`,
    `Moyenne total membre: ${moyenneMembre.toFixed(2)} FCFA`
  ];
  let y = 35;
  details.forEach(line => {
    doc.text(line, 14, y);
    y += 7;
  });

  // QR code (petit, cendré)
  const qrData = "Nom: BynaryBridge Studio\nTel: +22898774038\nEmail: jonathanarthurastre@gmail.com";
  const qrImage = await generateQRCodeDataUrl(qrData, "#999");

  // Table
  const head = [['Participant', 'Cotisation', 'Total payé', 'Total 31', 'Total membre', '% entreprise', '% membre']];
  const body = tableRows.map(r => [
    r.nom,
    r.cotisation.toLocaleString(),
    r.totalPerso.toLocaleString(),
    r.total31.toLocaleString(),
    r.totalMembre.toLocaleString(),
    r.pourcentageEntreprise.toFixed(1) + '%',
    r.pourcentageMembre.toFixed(1) + '%'
  ]);

  doc.autoTable({
    startY: y + 10,
    head,
    body,
    styles: { fontSize: 9 },
    headStyles: { fillColor: '#2563eb', textColor: '#fff' },
    theme: 'striped',
    margin: { left: 14, right: 14 },
    didDrawPage: (data) => {
      const pageHeight = doc.internal.pageSize.height;
      const pageWidth = doc.internal.pageSize.width;

      // Numéro de page
      doc.setFontSize(8);
      doc.setTextColor('#999');
      doc.text("Page " + doc.internal.getNumberOfPages(), data.settings.margin.left, pageHeight - 10);

      // Signature
      const signature = "powered by BynaryBridge Studio";
      const textWidth = doc.getTextWidth(signature);
      const textX = pageWidth - textWidth - 40;
      const textY = pageHeight - 10;
      doc.text(signature, textX, textY);

      // QR code discret
      const qrSize = 20;
      const qrX = pageWidth - qrSize - 14;
      const qrY = pageHeight - qrSize - 5;
      doc.addImage(qrImage, 'PNG', qrX, qrY, qrSize, qrSize);
    }
  });

  // Ajouter des liens cliquables dans le coin en bas (email et tel)
  doc.setFontSize(10);
  doc.setTextColor('#0ea5e9'); // bleu
  doc.textWithLink("jonathanarthurastre@gmail.com", 14, doc.internal.pageSize.height - 20, {
    url: "mailto:jonathanarthurastre@gmail.com"
  });
  doc.textWithLink("+22898774038", 14, doc.internal.pageSize.height - 14, {
    url: "tel:+22898774038"
  });

  // Optionnel : métadonnées PDF
  doc.setProperties({
    title: `Rapport Tontine CMA ${year}`,
    subject: 'Rapport financier coopérative',
    author: 'BynaryBridge Studio',
    keywords: 'tontine, rapport, coopérative',
    creator: 'BynaryBridge Studio'
  });

  doc.save(`rapport_tontine_${year}.pdf`);
};

// QR code en base64 avec couleur
function generateQRCodeDataUrl(text, color = "#000000") {
  return new Promise((resolve) => {
    const tempDiv = document.createElement('div');
    tempDiv.style.display = "none";
    document.body.appendChild(tempDiv);

    const qr = new QRCode(tempDiv, {
      text: text,
      width: 128,
      height: 128,
      colorDark: color,
      colorLight: "#ffffff",
      correctLevel: QRCode.CorrectLevel.H
    });

    setTimeout(() => {
      const img = tempDiv.querySelector('img');
      resolve(img.src);
      document.body.removeChild(tempDiv);
    }, 300);
  });
}


    }

    btn.addEventListener('click', afficherStats);
  }

  main();
})();