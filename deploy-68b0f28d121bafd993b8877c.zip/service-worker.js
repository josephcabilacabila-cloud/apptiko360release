// service-worker.js
// Version ultra-robuste et commentée pour PWA offline + runtime caching + background sync
'use strict';

const CACHE_VERSION = 'tontine-v3.0.0';
const PRECACHE = `${CACHE_VERSION}-precache`;
const RUNTIME = `${CACHE_VERSION}-runtime`;
const POST_QUEUE_DB = 'sw-post-queue'; // IndexedDB pour queue POST (Background Sync)
const POST_QUEUE_STORE = 'outbox';

const PRECACHE_URLS = [
  '/', // start_url (assure-toi que start_url dans manifest correspond)
  '/index.html',
  '/offline.html',
  '/manifest.json',
  '/icon.png',
  ,
  // Ajoute ici les ressources locales importantes (css, js, images) que tu veux toujours disponibles offline
  // Exemples :
  // '/styles/main.css',
  // '/app.js',
  // '/ba.png',
];

// paramétrage de limites pour caches runtime
const RUNTIME_SETTINGS = {
  images: { name: `${CACHE_VERSION}-images`, maxEntries: 120, maxAgeSeconds: 60 * 60 * 24 * 30 }, // 30j
  static: { name: `${CACHE_VERSION}-static`, maxEntries: 80, maxAgeSeconds: 60 * 60 * 24 * 30 },
  fonts: { name: `${CACHE_VERSION}-fonts`, maxEntries: 20, maxAgeSeconds: 60 * 60 * 24 * 365 },
  api: { name: `${CACHE_VERSION}-api`, maxEntries: 60, maxAgeSeconds: 60 * 60 * 24 * 7 } // 7j
};

// helper: timeout pour network-first
function networkTimeoutFetch(request, timeout = 7000) {
  return new Promise((resolve, reject) => {
    let timedOut = false;
    const timer = setTimeout(() => {
      timedOut = true;
      reject(new Error('network-timeout'));
    }, timeout);

    fetch(request).then(resp => {
      clearTimeout(timer);
      if (!timedOut) resolve(resp);
    }).catch(err => {
      clearTimeout(timer);
      reject(err);
    });
  });
}

/* ---------------------------
   IndexedDB helpers (small wrapper)
   used to queue failed POSTs for Background Sync
   --------------------------- */
function openIDB() {
  return new Promise((resolve, reject) => {
    const req = indexedDB.open(POST_QUEUE_DB, 1);
    req.onupgradeneeded = event => {
      const db = event.target.result;
      if (!db.objectStoreNames.contains(POST_QUEUE_STORE)) {
        db.createObjectStore(POST_QUEUE_STORE, { keyPath: 'id', autoIncrement: true });
      }
    };
    req.onsuccess = () => resolve(req.result);
    req.onerror = () => reject(req.error);
  });
}
async function idbAdd(item) {
  const db = await openIDB();
  return new Promise((resolve, reject) => {
    const tx = db.transaction(POST_QUEUE_STORE, 'readwrite');
    const store = tx.objectStore(POST_QUEUE_STORE);
    const r = store.add(item);
    r.onsuccess = () => resolve(r.result);
    r.onerror = () => reject(r.error);
  });
}
async function idbGetAll() {
  const db = await openIDB();
  return new Promise((resolve, reject) => {
    const tx = db.transaction(POST_QUEUE_STORE, 'readonly');
    const store = tx.objectStore(POST_QUEUE_STORE);
    const r = store.getAll();
    r.onsuccess = () => resolve(r.result || []);
    r.onerror = () => reject(r.error);
  });
}
async function idbDelete(key) {
  const db = await openIDB();
  return new Promise((resolve, reject) => {
    const tx = db.transaction(POST_QUEUE_STORE, 'readwrite');
    const store = tx.objectStore(POST_QUEUE_STORE);
    const r = store.delete(key);
    r.onsuccess = () => resolve();
    r.onerror = () => reject(r.error);
  });
}

/* ---------------------------
   Utility cache functions
   --------------------------- */
async function trimCache(cacheName, maxEntries) {
  const cache = await caches.open(cacheName);
  const keys = await cache.keys();
  if (keys.length <= maxEntries) return;
  const keysToDelete = keys.slice(0, keys.length - maxEntries);
  await Promise.all(keysToDelete.map(k => cache.delete(k)));
}
async function clearOldCaches() {
  const keys = await caches.keys();
  const keep = [PRECACHE, RUNTIME, RUNTIME_SETTINGS.images.name, RUNTIME_SETTINGS.static.name, RUNTIME_SETTINGS.fonts.name, RUNTIME_SETTINGS.api.name];
  await Promise.all(
    keys.map(k => (keep.includes(k) ? null : caches.delete(k)))
  );
}

/* ---------------------------
   INSTALL: pré-cache les fichiers essentiels
   --------------------------- */
self.addEventListener('install', event => {
  self.skipWaiting();
  event.waitUntil(
    (async () => {
      const cache = await caches.open(PRECACHE);
      try {
        await cache.addAll(PRECACHE_URLS);
      } catch (err) {
        // si addAll échoue (ex: réseau absent), tenter d'ajouter un par un pour diagnostiquer
        for (const url of PRECACHE_URLS) {
          try {
            await cache.add(url);
          } catch (e) {
            console.warn('Precache failed for', url, e);
          }
        }
      }
    })()
  );
});

/* ---------------------------
   ACTIVATE: nettoyage & prise de contrôle immédiate
   --------------------------- */
self.addEventListener('activate', event => {
  event.waitUntil(
    (async () => {
      await clearOldCaches();
      await clients.claim();
    })()
  );
});

/* ---------------------------
   FETCH: stratégies selon type de requête
   - Navigation (HTML) : network-first (fallback cache, offline.html)
   - CSS/JS : stale-while-revalidate
   - Images : cache-first (LRU trim)
   - Fonts : stale-while-revalidate
   - API GET : network-first with cache fallback
   - POST : try network, if fails enqueue for background sync
   --------------------------- */
self.addEventListener('fetch', event => {
  const request = event.request;
  const url = new URL(request.url);

  // ignore les devtools / chrome extensions
  if (url.protocol.startsWith('chrome-extension')) return;

  // Méthode POST -> on tente, sinon on met en queue (Background Sync)
  if (request.method === 'POST') {
    event.respondWith(
      (async () => {
        try {
          const fetchResp = await fetch(request.clone());
          // si réponse ok, la retourne
          return fetchResp;
        } catch (err) {
          // si background sync supporté, on sauvegarde la requête pour rejouer plus tard
          try {
            const body = await request.clone().json().catch(async () => {
              // si ce n'est pas JSON, on lit en texte/base64
              const txt = await request.clone().text();
              return { __raw_text: txt };
            });
            await idbAdd({
              url: request.url,
              method: request.method,
              headers: [...request.headers],
              body,
              timestamp: Date.now()
            });
            // demander une sync
            if ('sync' in self.registration) {
              await self.registration.sync.register('sw-post-sync');
            }
            // renvoyer réponse offline générique
            return new Response(JSON.stringify({ ok: false, offlineQueued: true }), {
              status: 503,
              headers: { 'Content-Type': 'application/json' }
            });
          } catch (queueErr) {
            return new Response('Offline and cannot queue', { status: 503 });
          }
        }
      })()
    );
    return;
  }

  // Navigation requests (navigating to an HTML page)
  if (request.mode === 'navigate' || (request.headers.get('accept') || '').includes('text/html')) {
    event.respondWith((async () => {
      try {
        // network-first with timeout
        const networkResponse = await networkTimeoutFetch(request, 7000);
        // update cache for navigation (use RUNTIME static)
        const cache = await caches.open(RUNTIME_SETTINGS.static.name);
        cache.put(request, networkResponse.clone().catch(()=>{}));
        return networkResponse;
      } catch (err) {
        // fallback to cached index.html or offline.html
        const cache = await caches.open(PRECACHE);
        const cached = await cache.match('/index.html') || await cache.match('/') || await cache.match('/offline.html');
        return cached || new Response('You are offline', { status: 503, headers: { 'Content-Type': 'text/plain' } });
      }
    })());
    return;
  }

  // Images -> cache-first
  if (request.destination === 'image' || /\.(png|jpg|jpeg|gif|webp|svg|ico)$/.test(url.pathname)) {
    event.respondWith((async () => {
      const cache = await caches.open(RUNTIME_SETTINGS.images.name);
      const cached = await cache.match(request);
      if (cached) return cached;
      try {
        const resp = await fetch(request);
        if (resp && resp.ok) {
          cache.put(request, resp.clone());
          trimCache(RUNTIME_SETTINGS.images.name, RUNTIME_SETTINGS.images.maxEntries);
        }
        return resp;
      } catch (err) {
        // fallback image (peux remplacer par '/offline-image.png' si tu l'ajoutes)
        const fallback = await caches.open(PRECACHE).then(c => c.match('/icon.png'));
        return fallback || new Response('', { status: 404 });
      }
    })());
    return;
  }

  // Fonts -> stale-while-revalidate
  if (request.destination === 'font' || /\.(woff2?|ttf|otf)$/.test(url.pathname)) {
    event.respondWith((async () => {
      const cache = await caches.open(RUNTIME_SETTINGS.fonts.name);
      const cached = await cache.match(request);
      const networkPromise = fetch(request).then(resp => {
        if (resp && resp.ok) cache.put(request, resp.clone());
        return resp;
      }).catch(() => null);
      return cached || (await networkPromise) || new Response(null, { status: 404 });
    })());
    return;
  }

  // CSS/JS -> stale-while-revalidate (fast boot)
  if (request.destination === 'script' || request.destination === 'style' || /\.(js|css)$/.test(url.pathname)) {
    event.respondWith((async () => {
      const cache = await caches.open(RUNTIME_SETTINGS.static.name);
      const cached = await cache.match(request);
      const networkPromise = fetch(request).then(resp => {
        if (resp && resp.ok) cache.put(request, resp.clone());
        return resp;
      }).catch(() => null);
      return cached || (await networkPromise) || new Response('', { status: 404 });
    })());
    return;
  }

  // API GET -> network-first fallback cache
  if (url.pathname.startsWith('/api') || url.hostname.includes('api')) {
    event.respondWith((async () => {
      const cache = await caches.open(RUNTIME_SETTINGS.api.name);
      try {
        const resp = await fetch(request);
        if (resp && resp.ok) {
          cache.put(request, resp.clone());
        }
        return resp;
      } catch (err) {
        const cached = await cache.match(request);
        return cached || new Response(JSON.stringify({ offline: true }), { status: 503, headers: { 'Content-Type': 'application/json' } });
      }
    })());
    return;
  }

  // Default: try cache first, else network
  event.respondWith((async () => {
    const cache = await caches.open(RUNTIME);
    const cached = await cache.match(request);
    if (cached) return cached;
    try {
      const resp = await fetch(request);
      if (resp && resp.ok) {
        cache.put(request, resp.clone());
      }
      return resp;
    } catch (err) {
      // fallback to precached offline page for navigation handled above; otherwise 503
      return new Response('Offline', { status: 503 });
    }
  })());
});

/* ---------------------------
   Background sync: rejouer les POST enregistrés
   --------------------------- */
self.addEventListener('sync', event => {
  if (event.tag === 'sw-post-sync') {
    event.waitUntil(
      (async () => {
        const queued = await idbGetAll();
        for (const item of queued) {
          try {
            // reconstruire la requête
            const headers = new Headers(item.headers || []);
            let body = null;
            if (item.body && item.body.__raw_text) {
              body = item.body.__raw_text;
            } else {
              body = JSON.stringify(item.body);
            }
            const resp = await fetch(item.url, { method: item.method, body, headers });
            if (resp && (resp.status >= 200 && resp.status < 300)) {
              await idbDelete(item.id);
            } else {
              // si la réponse n'est pas OK, on laisse en queue (pour réessayer plus tard)
              console.warn('Replay POST responded with non-ok', resp.status, item);
            }
          } catch (err) {
            console.warn('Replay POST failed, will retry later', err);
          }
        }
      })()
    );
  }
});

/* ---------------------------
   Message API from page
   - SKIP_WAITING: immediate activation
   - DOWNLOAD_OFFLINE: cache all resources in PRECACHE_URLS + optional list
   - CACHE_URLS: add given urls to cache
   --------------------------- */
self.addEventListener('message', event => {
  const data = event.data || {};
  if (data && data.type) {
    if (data.type === 'SKIP_WAITING') {
      self.skipWaiting();
    } else if (data.type === 'DOWNLOAD_OFFLINE') {
      event.waitUntil((async () => {
        const cache = await caches.open(PRECACHE);
        const currentCached = await cache.keys();
        const cachedUrls = currentCached.map(r => new URL(r.url).pathname);
        const toCache = PRECACHE_URLS.concat(data.urls || []).filter(u => !cachedUrls.includes(u));
        await Promise.all(toCache.map(u => cache.add(u).catch(e => console.warn('Download offline failed for', u, e))));
      })());
    } else if (data.type === 'CACHE_URLS') {
      event.waitUntil((async () => {
        const cache = await caches.open(RUNTIME);
        const urls = data.urls || [];
        await Promise.all(urls.map(u => fetch(u).then(r => cache.put(u, r)).catch(e => console.warn('cache urls failed', e))));
      })());
    }
  }
});

/* ---------------------------
   Notify clients when a new SW took control (useful to show "update available")
   We send a message on 'controllerchange' from the page side; here we can also post messages.
   --------------------------- */
async function broadcastMessage(msg) {
  const all = await clients.matchAll({ includeUncontrolled: true, type: 'window' });
  for (const client of all) {
    client.postMessage(msg);
  }
}

// detect new service worker activation and notify
self.addEventListener('activate', event => {
  event.waitUntil((async () => {
    await broadcastMessage({ type: 'SW_ACTIVATED', version: CACHE_VERSION });
  })());
});
