window.addEventListener('DOMContentLoaded', () => {
  // --- Détection de l'heure et du jour ---
  const now = new Date();
  const hour = now.getHours();
  const day = now.getDay(); // 0 = Dimanche, 6 = Samedi

  // --- Salutations selon l'heure ---
  const salutations = {
    matin: ["Bonjour", "Salut", "Coucou", "Hello"],
    apresMidi: ["Bon après-midi", "Rebonjour", "Salut encore", "Hello à nouveau"],
    soir: ["Bonsoir", "Salut du soir", "Bonsoir à vous", "Hello du soir"]
  };

  let salutation = '';
  if (hour >= 5 && hour < 12) salutation = salutations.matin[Math.floor(Math.random() * salutations.matin.length)];
  else if (hour >= 12 && hour < 18) salutation = salutations.apresMidi[Math.floor(Math.random() * salutations.apresMidi.length)];
  else salutation = salutations.soir[Math.floor(Math.random() * salutations.soir.length)];

  // --- Compléments selon le jour ---
  const joursSemaine = [
    ["En ce beau dimanche", "En ce dimanche paisible", "En ce dimanche plein de sérénité"],
    ["En ce lundi productif", "En ce lundi motivant", "En ce lundi plein d'énergie"],
    ["En ce mardi motivant", "En ce mardi ensoleillé", "En ce mardi dynamique"],
    ["En ce mercredi dynamique", "En ce mercredi tranquille", "En ce mercredi radieux"],
    ["En ce jeudi prometteur", "En ce jeudi brillant", "En ce jeudi motivant"],
    ["En ce vendredi plein d'énergie", "En ce vendredi détendu", "En ce vendredi joyeux"],
    ["En ce samedi reposant", "En ce samedi ensoleillé", "En ce samedi agréable"]
  ];
  const jourPhrase = joursSemaine[day][Math.floor(Math.random() * joursSemaine[day].length)];

  // --- Message complet ---
const message = `${salutation}, ${jourPhrase} et bienvenue sur l'application 360TIKOO, propulsée par Binarybridge Studio LTD.`;

  // --- Synthèse vocale ---
  if ('speechSynthesis' in window) {
    const speakMessage = () => {
      const utterance = new SpeechSynthesisUtterance(message);
      utterance.lang = 'fr-FR';
      utterance.rate = 0.95;
      utterance.pitch = 0.9;
      utterance.volume = 1;

      // Sélection de la voix française préférée
      const voices = speechSynthesis.getVoices();
      const preferredVoices = voices.filter(v =>
        v.lang.startsWith('fr') &&
        /google français|thomas|paul|male|homme/i.test(v.name)
      );
      utterance.voice = preferredVoices[0] || voices.find(v => v.lang.startsWith('fr')) || null;

      speechSynthesis.speak(utterance);
    };

    // Les voix peuvent ne pas être chargées immédiatement
    if (speechSynthesis.getVoices().length === 0) {
      speechSynthesis.onvoiceschanged = speakMessage;
    } else {
      speakMessage();
    }
  } else {
    console.warn("La synthèse vocale n'est pas supportée par ce navigateur.");
  }
});
