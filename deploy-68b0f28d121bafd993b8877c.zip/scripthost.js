
(() => {
  const currentYear = new Date().getFullYear();

  const PARTICIPANTS_KEY = 'tontine_participants';
  const PAYMENTS_KEY = 'tontine_payments';

  // --- Stockage Participants ---
  function getStoredParticipants() {
    const data = localStorage.getItem(PARTICIPANTS_KEY);
    return data ? JSON.parse(data) : [];
  }
  function saveStoredParticipants(participants) {
    localStorage.setItem(PARTICIPANTS_KEY, JSON.stringify(participants));
  }

  // --- Stockage Paiements ---
  function getStoredPayments() {
    const data = localStorage.getItem(PAYMENTS_KEY);
    return data ? JSON.parse(data) : {};
  }
  function saveStoredPayments(payments) {
    localStorage.setItem(PAYMENTS_KEY, JSON.stringify(payments));
  }

  // --- Format Date YYYY-MM-DD ---
  function formatDate(year, month, day) {
    const mm = month.toString().padStart(2, '0');
    const dd = day.toString().padStart(2, '0');
    return `${year}-${mm}-${dd}`;
  }

  // --- DOM Elements ---
  const container = document.getElementById('participants-container');
  const searchInput = document.getElementById('search-input');
  const modalOverlay = document.getElementById('modal-overlay');
  const btnAddParticipant = document.getElementById('btn-add-participant');
  const btnCancelModal = document.getElementById('btn-cancel-modal');
  const formAddParticipant = document.getElementById('form-add-participant');

  // --- Variables ---
  let editingIndex = null;

  // --- Modal open/close ---
  function openModal(editing = false, participant = null) {
    modalOverlay.style.display = 'flex';
    if (editing && participant) {
      formAddParticipant.firstname.value = participant.firstname;
      formAddParticipant.lastname.value = participant.lastname;
      formAddParticipant.cotisation.value = participant.cotisation;
      formAddParticipant.frequency.value = participant.frequency;
    } else {
      formAddParticipant.reset();
    }
    document.getElementById('input-firstname').focus();
    document.body.style.overflow = 'hidden';
  }
  function closeModal() {
    modalOverlay.style.display = 'none';
    document.body.style.overflow = '';
    editingIndex = null;
  }
  btnAddParticipant.addEventListener('click', () => {
    editingIndex = null;
    openModal(false);
  });
  btnCancelModal.addEventListener('click', closeModal);
  modalOverlay.addEventListener('click', e => {
    if (e.target === modalOverlay) closeModal();
  });
  modalOverlay.addEventListener('keydown', e => {
    if (e.key === 'Escape') closeModal();
  });

  // --- Form submit ---
  formAddParticipant.addEventListener('submit', e => {
    e.preventDefault();
    const firstname = formAddParticipant.firstname.value.trim();
    const lastname = formAddParticipant.lastname.value.trim();
    const cotisation = parseInt(formAddParticipant.cotisation.value, 10);
    const frequency = formAddParticipant.frequency.value;

    if (firstname.length < 2 || lastname.length < 2 || isNaN(cotisation) || cotisation < 100) {
      alert('Veuillez remplir correctement tous les champs. Cotisation minimum 100 FCFA.');
      return;
    }

    const participants = getStoredParticipants();

    // Vérification doublon nom+prénom (insensible à la casse), sauf si édition sur même index
    const exists = participants.some((p, idx) =>
      idx !== editingIndex &&
      p.firstname.toLowerCase() === firstname.toLowerCase() &&
      p.lastname.toLowerCase() === lastname.toLowerCase()
    );
    if (exists) {
      alert('Ce participant existe déjà.');
      return;
    }

    if (editingIndex !== null) {
      // Modifier participant existant
      participants[editingIndex] = { firstname, lastname, cotisation, frequency };
      saveStoredParticipants(participants);
      alert(`Participant ${firstname} ${lastname} modifié avec succès.`);
    } else {
      // Ajouter nouveau participant
      participants.push({ firstname, lastname, cotisation, frequency });
      saveStoredParticipants(participants);
      alert(`Participant ${firstname} ${lastname} ajouté avec succès.`);
    }

    closeModal();
    searchInput.value = `${firstname} ${lastname}`;
    displayParticipants(searchInput.value);
    updateDashboard();
  });

  // --- Chargement et sauvegarde paiements ---
  function loadPayments(participantIndex) {
    const payments = getStoredPayments();
    return payments[participantIndex] || {};
  }
  function savePayments(participantIndex, paymentsObj) {
    const allPayments = getStoredPayments();
    allPayments[participantIndex] = paymentsObj;
    saveStoredPayments(allPayments);
  }

function createCarnetTable(participantIndex, participant) {
  const payments = loadPayments(participantIndex);
  const freq = participant.frequency || 'jour';

  const table = document.createElement('table');
  table.setAttribute('aria-label', `Carnet de paiements de ${participant.firstname} ${participant.lastname}`);

  const thead = document.createElement('thead');
  const headerRow = document.createElement('tr');
  headerRow.appendChild(document.createElement('th'));

  const months = ["Jan", "Fév", "Mar", "Avr", "Mai", "Juin", "Juil", "Août", "Sep", "Oct", "Nov", "Déc"];
  months.forEach(m => {
    const th = document.createElement('th');
    th.textContent = m;
    th.classList.add('month-col');
    headerRow.appendChild(th);
  });
  thead.appendChild(headerRow);
  table.appendChild(thead);

  const tbody = document.createElement('tbody');
  const currentYear = new Date().getFullYear();

  let isDragging = false;
  let dragState = false;
  const visitedCells = new Set();
  const changedDates = new Set();
  let rafScheduled = false;

  function updateVisual(td, state) {
    td.classList.toggle('paid', state);
    td.classList.toggle('unpaid', !state);
    td.textContent = state ? '✔' : '';
    td.setAttribute('aria-checked', state.toString());
  }

  function scheduleSaveAndUpdate() {
    if (!rafScheduled) {
      rafScheduled = true;
      requestAnimationFrame(() => {
        savePayments(participantIndex, payments);
        updateDashboard();
        rafScheduled = false;
      });
    }
  }

  for (let day = 1; day <= 31; day++) {
    const tr = document.createElement('tr');
    const dayCell = document.createElement('th');
    dayCell.textContent = day;
    dayCell.setAttribute('scope', 'row');
    tr.appendChild(dayCell);

    for (let month = 1; month <= 12; month++) {
      const td = document.createElement('td');
      td.classList.add('day-col');

      const dateStr = formatDate(currentYear, month, day);
      const isPaid = payments[dateStr] === true;
      updateVisual(td, isPaid);

      td.setAttribute('tabindex', '0');
      td.setAttribute('role', 'checkbox');
      td.setAttribute('aria-label', `${dateStr} - ${isPaid ? 'payé' : 'non payé'}`);

      // Clic simple
      td.addEventListener('click', () => {
        const newState = !payments[dateStr];
        if (newState) payments[dateStr] = true;
        else delete payments[dateStr];
        updateVisual(td, newState);
        savePayments(participantIndex, payments);
        updateDashboard();
      });

      // Clavier
      td.addEventListener('keydown', (e) => {
        if (e.key === ' ' || e.key === 'Enter') {
          e.preventDefault();
          td.click();
        }
      });

      // Souris (drag)
      td.addEventListener('mousedown', (e) => {
        e.preventDefault();
        isDragging = true;
        dragState = !payments[dateStr];
        visitedCells.clear();
        changedDates.clear();

        if (dragState) payments[dateStr] = true;
        else delete payments[dateStr];
        updateVisual(td, dragState);
        visitedCells.add(td);
        changedDates.add(dateStr);
      });

      td.addEventListener('mouseover', () => {
        if (isDragging && !visitedCells.has(td)) {
          if (dragState) payments[dateStr] = true;
          else delete payments[dateStr];
          updateVisual(td, dragState);
          visitedCells.add(td);
          changedDates.add(dateStr);
        }
      });

      // Touchscreen (mobile Android)
      td.addEventListener('touchstart', (e) => {
        e.preventDefault();
        isDragging = true;
        dragState = !payments[dateStr];
        visitedCells.clear();
        changedDates.clear();

        if (dragState) payments[dateStr] = true;
        else delete payments[dateStr];
        updateVisual(td, dragState);
        visitedCells.add(td);
        changedDates.add(dateStr);
      }, { passive: false });

      td.addEventListener('touchmove', (e) => {
        const touch = e.touches[0];
        const target = document.elementFromPoint(touch.clientX, touch.clientY);
        if (isDragging && target && target.tagName === 'TD' && !visitedCells.has(target)) {
          const targetDate = target.getAttribute('aria-label').split(' - ')[0];
          if (dragState) payments[targetDate] = true;
          else delete payments[targetDate];
          updateVisual(target, dragState);
          visitedCells.add(target);
          changedDates.add(targetDate);
        }
      }, { passive: false });

      tr.appendChild(td);
    }

    tbody.appendChild(tr);
  }

  table.appendChild(tbody);

  // Fin du drag (souris)
  document.addEventListener('mouseup', () => {
    if (isDragging) {
      isDragging = false;
      visitedCells.clear();
      if (changedDates.size > 0) {
        savePayments(participantIndex, payments);
        updateDashboard();
        changedDates.clear();
      }
    }
  });

  // Fin du drag (tactile)
  document.addEventListener('touchend', () => {
    if (isDragging) {
      isDragging = false;
      visitedCells.clear();
      if (changedDates.size > 0) {
        savePayments(participantIndex, payments);
        updateDashboard();
        changedDates.clear();
      }
    }
  });
const wrapper = document.createElement('div');
wrapper.classList.add('table-wrapper');
wrapper.appendChild(table);
return wrapper;
}


  // --- Affichage des participants ---
  function displayParticipants(filterText = '') {
    const participants = getStoredParticipants();
    const normalizedFilter = filterText.trim().toLowerCase();

    container.innerHTML = '';

    // NE RIEN AFFICHER SI FILTRE VIDE
    if (!normalizedFilter) {
      return;
    }
   


    participants.forEach((p, i) => {
      const fullname = `${p.firstname} ${p.lastname}`.toLowerCase();
      if (!fullname.includes(normalizedFilter)) return;

      const div = document.createElement('div');
      div.className = 'person-item';
      div.setAttribute('tabindex', '0');
      div.setAttribute('aria-label', `Carnet de ${p.firstname} ${p.lastname}`);

      const header = document.createElement('div');
      header.className = 'person-header';

      const nameEl = document.createElement('h3');
      nameEl.textContent = `${p.firstname} ${p.lastname}`;
      header.appendChild(nameEl);

      const infoEl = document.createElement('div');
      infoEl.className = 'person-info';
      infoEl.textContent = `Cotisation : ${p.cotisation.toLocaleString()} FCFA`;
      header.appendChild(infoEl);

      div.appendChild(header);

      const freqEl = document.createElement('div');
      freqEl.className = 'frequency-info';
      freqEl.textContent = `Fréquence cotisation : ${
        p.frequency === 'jour' ? 'Journalier' : p.frequency === 'semaine' ? 'Hebdomadaire' : 'Mensuel'
      }`;
      div.appendChild(freqEl);

      const table = createCarnetTable(i, p);
      div.appendChild(table);

      const totalPaid = calculateTotalPaid(i, p);
      const totalEl = document.createElement('p');
      totalEl.className = 'total-paid';
      totalEl.textContent = `Total payé : ${totalPaid.toLocaleString()} FCFA`;
      div.appendChild(totalEl);

      const btnsDiv = document.createElement('div');
      btnsDiv.className = 'btns-carnet';

     // Imprimer
const btnPrint = document.createElement('button');
btnPrint.textContent = 'Impression';
btnPrint.setAttribute('aria-label', `Impression du carnet de ${p.firstname} ${p.lastname}`);

// Remplacer printCarnet par downloadBulletinPDF
btnPrint.addEventListener('click', () => {
    downloadBulletinPDF(i, p);
});

btnsDiv.appendChild(btnPrint);

      // Reset paiement
      const btnReset = document.createElement('button');
      btnReset.textContent = 'Réinitialiser paiements';
      btnReset.className = 'btn-reset';
      btnReset.setAttribute('aria-label', `Réinitialiser les paiements de ${p.firstname} ${p.lastname}`);
      btnReset.addEventListener('click', () => {
        if (confirm(`Voulez-vous vraiment réinitialiser tous les paiements de ${p.firstname} ${p.lastname} ?`)) {
          savePayments(i, {});
          displayParticipants(filterText);
          updateDashboard();
        }
      });
      btnsDiv.appendChild(btnReset);

      // Modifier participant
      const btnEdit = document.createElement('button');
      btnEdit.textContent = 'Modifier';
      btnEdit.className = 'btn-edit';
      btnEdit.setAttribute('aria-label', `Modifier ${p.firstname} ${p.lastname}`);
      btnEdit.addEventListener('click', () => {
        editingIndex = i;
        openModal(true, p);
      });
      btnsDiv.appendChild(btnEdit);

      // Supprimer participant
      const btnDelete = document.createElement('button');
      btnDelete.textContent = 'Supprimer';
      btnDelete.className = 'btn-delete';
      btnDelete.setAttribute('aria-label', `Supprimer ${p.firstname} ${p.lastname}`);
      btnDelete.addEventListener('click', () => {
        if (confirm(`Voulez-vous vraiment supprimer ${p.firstname} ${p.lastname} ?`)) {
          const parts = getStoredParticipants();
          parts.splice(i, 1);
          saveStoredParticipants(parts);
          // Supprimer paiements associés
          const allPayments = getStoredPayments();
          delete allPayments[i];
          // Important : Réindexer paiements des participants suivants
          const newPayments = {};
          Object.keys(allPayments).forEach(key => {
            const k = parseInt(key);
            newPayments[k < i ? k : k - 1] = allPayments[key];
          });
          saveStoredPayments(newPayments);
          displayParticipants(filterText);
          updateDashboard();
        }
      });
      btnsDiv.appendChild(btnDelete);

      div.appendChild(btnsDiv);

      container.appendChild(div);
    });
  }

  // --- Calcul total payé pour un participant ---
  function calculateTotalPaid(index, participant) {
    const payments = getStoredPayments()[index] || {};
    let count = 0;
    for (const dateStr in payments) {
      if (payments[dateStr]) count++;
    }
    return (participant.cotisation || 0) * count;
  }

 function updateDashboard() {
  const participants = getStoredParticipants();
  const payments = getStoredPayments();

  const totalEl = document.getElementById('total-collected-modal');
  const avgEl = document.getElementById('average-daily-modal');
  const rankingEl = document.getElementById('ranking-list-modal');

  if (participants.length === 0) {
    totalEl.textContent = "Aucun participant enregistré.";
    avgEl.textContent = "";
    rankingEl.innerHTML = "";
    return;
  }

  let totalCotisations = 0;
  let totalPaid = 0;
  const classement = [];

  participants.forEach((p, i) => {
    let expectedPayments = 0;
    if (p.frequency === 'jour') expectedPayments = 365;
    else if (p.frequency === 'semaine') expectedPayments = 52;
    else if (p.frequency === 'mois') expectedPayments = 12;

    totalCotisations += (p.cotisation || 0) * expectedPayments;

    const totalPerso = calculateTotalPaid(i, p);
    totalPaid += totalPerso;

    classement.push({
      nom: `${p.firstname} ${p.lastname}`,
      total: totalPerso
    });
  });

  const moyenneAnn = totalCotisations / participants.length;
  const moyennePayee = totalPaid / participants.length;

  totalEl.textContent = `Total collecté : ${totalPaid.toLocaleString()} FCFA`;
  avgEl.textContent = `Moyenne cotisation/jour/membre : ${moyennePayee.toLocaleString(undefined, { maximumFractionDigits: 2 })} FCFA`;

  classement.sort((a, b) => b.total - a.total);
  rankingEl.innerHTML = "";
  classement.forEach(item => {
    const li = document.createElement('li');
    li.textContent = `${item.nom} - ${item.total.toLocaleString()} FCFA`;
    rankingEl.appendChild(li);
  });
}
// Ouvrir le modal de statistiques
document.getElementById('show-stats-btn').addEventListener('click', () => {
  updateDashboard();
  document.getElementById('stats-modal-overlay').style.display = 'flex';
  document.body.style.overflow = 'hidden';
});

// Fermer le modal
document.getElementById('close-stats-modal').addEventListener('click', () => {
  document.getElementById('stats-modal-overlay').style.display = 'none';
  document.body.style.overflow = '';
});

// Fermer si clic hors du modal
document.getElementById('stats-modal-overlay').addEventListener('click', (e) => {
  if (e.target.id === 'stats-modal-overlay') {
    document.getElementById('stats-modal-overlay').style.display = 'none';
    document.body.style.overflow = '';
  }
});



  // --- Recherche en temps réel ---
  searchInput.addEventListener('input', () => {
    displayParticipants(searchInput.value);
  });
// --- Fonction pour parler ---
function speakMessage(message) {
  if ('speechSynthesis' in window) {
    const utterance = new SpeechSynthesisUtterance(message);
    utterance.lang = 'fr-FR';
    window.speechSynthesis.speak(utterance);
  }
}

// --- Fonction pour jouer un bip sonore ---
function playBeep(type = 'success') {
  const context = new (window.AudioContext || window.webkitAudioContext)();
  const oscillator = context.createOscillator();
  const gainNode = context.createGain();

  oscillator.connect(gainNode);
  gainNode.connect(context.destination);

  if (type === 'success') {
    oscillator.frequency.value = 880; // Hz, son aigu
  } else {
    oscillator.frequency.value = 220; // Hz, son grave
  }

  gainNode.gain.value = 0.2; // volume
  oscillator.start();
  oscillator.stop(context.currentTime + 0.15); // durée 150ms
}

// --- Export JSON ---
document.getElementById('btn-export-json').addEventListener('click', () => {
  const data = {
    [PARTICIPANTS_KEY]: getStoredParticipants(),
    [PAYMENTS_KEY]: getStoredPayments()
  };

  try {
    const jsonStr = JSON.stringify(data, null, 2);
    const blob = new Blob([jsonStr], { type: 'application/json' });
    const url = URL.createObjectURL(blob);

    const a = document.createElement('a');
    a.href = url;
    a.download = 'tontine_data.json';
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);

    speakMessage('Données exportées avec succès !'); // 🔊 Voix
    playBeep('success'); // 🔔 Bip succès
  } catch (err) {
    speakMessage('Erreur lors de l’exportation des données.'); // 🔊 Voix
    playBeep('error'); // 🔔 Bip erreur
    console.error(err);
  }
});

// --- Import JSON robuste et sans reload ---
document.getElementById('import-json-file').addEventListener('change', (event) => {
  const file = event.target.files[0];
  if (!file) return;

  const reader = new FileReader();
  reader.onload = function (e) {
    try {
      const data = JSON.parse(e.target.result);

      if (!data[PARTICIPANTS_KEY] || !data[PAYMENTS_KEY]) {
        speakMessage('Fichier JSON invalide ou corrompu.');
        playBeep('error');
        return;
      }

      const existingParticipants = getStoredParticipants();
      const existingPayments = getStoredPayments();

      // Filtrer et valider les participants importés
      const newParticipants = data[PARTICIPANTS_KEY].filter(p => {
        return p.firstname && p.lastname && typeof p.cotisation === 'number' && p.frequency;
      });

      // Ajouter uniquement les participants non existants (doublons nom+prenom)
      newParticipants.forEach(p => {
        const duplicate = existingParticipants.some(ep =>
          ep.firstname.toLowerCase() === p.firstname.toLowerCase() &&
          ep.lastname.toLowerCase() === p.lastname.toLowerCase()
        );
        if (!duplicate) existingParticipants.push(p);
      });

      // Valider les paiements importés
      const newPayments = {};
      Object.keys(data[PAYMENTS_KEY]).forEach(key => {
        if (typeof data[PAYMENTS_KEY][key] === 'object') {
          newPayments[key] = data[PAYMENTS_KEY][key];
        }
      });

      // Sauvegarder
      saveStoredParticipants(existingParticipants);
      saveStoredPayments({...existingPayments, ...newPayments});

      // Mise à jour UI
      speakMessage('Données importées avec succès !');
      playBeep('success');
      displayParticipants(searchInput.value);
      updateDashboard();
    } catch (err) {
      speakMessage('Erreur lors de la lecture du fichier JSON.');
      playBeep('error');
      console.error(err);
    }
  };
  reader.readAsText(file);
});

// --- Raccourcis clavier avancés avec sélection de participant ---
let selectedIndex = 0; // index du participant sélectionné dans la liste filtrée

function getVisibleParticipants() {
  return Array.from(document.querySelectorAll('.person-item'));
}

function selectParticipant(index) {
  const participants = getVisibleParticipants();
  if (participants.length === 0) return;
  // Retirer la sélection précédente
  participants.forEach(p => p.classList.remove('selected'));
  // Clamp index
  selectedIndex = Math.max(0, Math.min(index, participants.length - 1));
  participants[selectedIndex].classList.add('selected');
  participants[selectedIndex].scrollIntoView({ block: 'nearest', behavior: 'smooth' });
}

// Initialisation : sélectionner le premier participant
selectParticipant(0);

document.addEventListener('keydown', (e) => {
  if (e.metaKey) return; // éviter les conflits système

  const participants = getVisibleParticipants();
  if (participants.length === 0) return;

  switch (true) {
    case e.shiftKey && !e.ctrlKey && !e.altKey && e.key.toLowerCase() === 'a':
      btnAddParticipant.click();
      e.preventDefault();
      break;

    case e.altKey && !e.ctrlKey && !e.shiftKey && e.key.toLowerCase() === 's':
      document.getElementById('show-stats-btn').click();
      e.preventDefault();
      break;

    case e.altKey && !e.ctrlKey && !e.shiftKey && e.key.toLowerCase() === 'r':
      // Réinitialiser paiements du participant sélectionné
      const resetBtn = participants[selectedIndex].querySelector('.btn-reset');
      if (resetBtn) resetBtn.click();
      e.preventDefault();
      break;

    case e.shiftKey && !e.ctrlKey && !e.altKey && e.key.toLowerCase() === 'e':
      const editBtn = participants[selectedIndex].querySelector('.btn-edit');
      if (editBtn) editBtn.click();
      e.preventDefault();
      break;

    case e.altKey && !e.ctrlKey && !e.shiftKey && e.key.toLowerCase() === 'd':
      const deleteBtn = participants[selectedIndex].querySelector('.btn-delete');
      if (deleteBtn) deleteBtn.click();
      e.preventDefault();
      break;

    case e.ctrlKey && !e.altKey && !e.shiftKey && e.key.toLowerCase() === 'f':
      searchInput.focus();
      e.preventDefault();
      break;

    case e.shiftKey && !e.ctrlKey && !e.altKey && e.key.toLowerCase() === 'p':
      const printBtn = participants[selectedIndex].querySelector('button[aria-label^="Impression"]');
      if (printBtn) printBtn.click();
      e.preventDefault();
      break;

    case e.key === 'ArrowDown':
      selectParticipant(selectedIndex + 1);
      e.preventDefault();
      break;

    case e.key === 'ArrowUp':
      selectParticipant(selectedIndex - 1);
      e.preventDefault();
      break;

    default:
      break;
  }
});

  // --- Initialisation ---
  updateDashboard();
  displayParticipants(searchInput.value);
})();
