(() => {
  const containerId = 'tontine-widget-container';
  let container = document.getElementById(containerId);
  if (!container) {
    container = document.createElement('div');
    container.id = containerId;
    document.body.appendChild(container);
  }

  // Ajouter le style si pas déjà présent
  if (!document.getElementById(`${containerId}-style`)) {
    const style = document.createElement('style');
    style.id = `${containerId}-style`;
    style.textContent = `
      #${containerId} #open-tontine-modal-btn {
      position: relative;
      bottom: 25px;
      right: 25px;
      background-color: #3b82f6;
      color: white;
      border: none;
      padding: 12px 20px;
      font-size: 16px;
      cursor: pointer;
      box-shadow: 0 4px 12px rgba(59,130,246,0.4);
      display: flex;
      align-items: center;
      gap: 10px;
      z-index: 9999;
      font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
      transition: background-color 0.25s ease;
      font-weight: bold;
    }
    #${containerId} #open-tontine-modal-btn:hover { background-color: #2563eb; }

      #${containerId} #modal-overlay {
        position: fixed; inset: 0;
        background-color: rgba(0,0,0,0.5);
        display: none;
        justify-content: center;
        align-items: center;
        z-index: 10000;
      }
      #${containerId} #modal-tontine-members {
        background: white;
        border-radius: 12px;
        max-width: 450px;
        width: 90%;
        max-height: 80vh;
        overflow-y: auto;
        box-shadow: 0 12px 24px rgba(0,0,0,0.15);
        padding: 25px 30px 30px;
        position: relative;
        color: #111;
      }
      #${containerId} #modal-tontine-members h2 {
        margin-top: 0;
        margin-bottom: 20px;
        font-weight: 700;
        font-size: 22px;
        text-align: center;
        color: #2563eb;
      }
      #${containerId} #alert-section {
        margin-bottom: 15px;
        padding: 12px 15px;
        border-radius: 8px;
        font-weight: 600;
        font-size: 15px;
      }
      #${containerId} #alert-section.late { background-color: #fee2e2; color: #b91c1c; }
      #${containerId} #alert-section.none { background-color: #d1fae5; color: #065f46; }
      #${containerId} table {
        width: 100%;
        border-collapse: collapse;
        font-size: 16px;
        color: #333;
      }
      #${containerId} th, #${containerId} td {
        border-bottom: 1px solid #e5e7eb;
        padding: 10px 12px;
        text-align: left;
      }
      #${containerId} th {
        background-color: #f3f4f6;
        font-weight: 600;
        color: #2563eb;
      }
      #${containerId} tr:last-child td { border-bottom: none; }
      #${containerId} #modal-close-btn {
        position: absolute; top: 15px; right: 15px;
        background: #ef4444; color: white; border: none;
        padding: 6px 12px; border-radius: 30px;
        cursor: pointer; font-size: 14px; font-weight: 600;
      }
      #${containerId} #modal-close-btn:hover { background-color: #b91c1c; }
      #${containerId} #export-pdf-btn {
        background-color: #2563eb; color: white; border: none;
        border-radius: 30px; padding: 10px 18px; font-size: 15px;
        cursor: pointer; margin-bottom: 15px; display: block;
      }
      #${containerId} input[type="text"] {
        display: block; width: 100%; padding: 12px 16px;
        font-size: 15px; margin-bottom: 16px;
        border: 1px solid #d1d5db; border-radius: 8px;
        background-color: #f9fafb;
      }
    `;
    container.appendChild(style);
  }

  if (!document.getElementById('open-tontine-modal-btn')) {
    const openBtn = document.createElement('button');
    openBtn.id = 'open-tontine-modal-btn';
    openBtn.innerHTML = `<i class="fa fa-users"></i> Member`;
    container.appendChild(openBtn);

    const modalOverlay = document.createElement('div');
    modalOverlay.id = 'modal-overlay';

    const modal = document.createElement('div');
    modal.id = 'modal-tontine-members';

    const title = document.createElement('h2');
    title.textContent = 'Membres de la tontine';

    const alertSection = document.createElement('div');
    alertSection.id = 'alert-section';

    const listContainer = document.createElement('div');
    listContainer.id = 'tontine-members-list';

    const exportPdfBtn = document.createElement('button');
    exportPdfBtn.id = 'export-pdf-btn';
    exportPdfBtn.textContent = 'Exporter en PDF';

    const closeBtn = document.createElement('button');
    closeBtn.id = 'modal-close-btn';
    closeBtn.textContent = 'Fermer';

    modal.appendChild(title);
    modal.appendChild(alertSection);
    modal.appendChild(exportPdfBtn);
    modal.appendChild(listContainer);
    modal.appendChild(closeBtn);
    modalOverlay.appendChild(modal);
    container.appendChild(modalOverlay);

    function getStoredParticipants() {
      try {
        const data = localStorage.getItem('tontine_participants');
        return data ? JSON.parse(data) : [];
      } catch (e) {
        console.warn('Impossible d’accéder à localStorage', e);
        return [];
      }
    }

    function displayMembers() {
      const participants = getStoredParticipants();
      listContainer.innerHTML = '';
      alertSection.innerHTML = '';

      const lateMembers = participants.filter(p => p.isLate);

      if (lateMembers.length > 0) {
        alertSection.className = 'late';
        alertSection.textContent = `⚠️ ${lateMembers.length} membre(s) en retard : `;
        const namesSpan = document.createElement('span');
        namesSpan.textContent = lateMembers.map(m => `${m.firstname} ${m.lastname}`).join(', ');
        alertSection.appendChild(namesSpan);
      } else {
        alertSection.className = 'none';
        alertSection.textContent = '✅ Aucun retard pour le moment.';
      }

      if (participants.length === 0) {
        listContainer.innerHTML = '<p>Aucun membre dans la tontine.</p>';
        exportPdfBtn.disabled = true;
        exportPdfBtn.style.opacity = 0.5;
        return;
      } else {
        exportPdfBtn.disabled = false;
        exportPdfBtn.style.opacity = 1;
      }

      const searchWrapper = document.createElement('div');
      searchWrapper.style.position = 'relative';
      searchWrapper.style.marginBottom = '16px';

      const searchInput = document.createElement('input');
      searchInput.type = 'text';
      searchInput.placeholder = 'Rechercher un membre...';
      searchInput.style.width = '100%';
      searchInput.style.paddingLeft = '35px';

      const searchIcon = document.createElement('i');
      searchIcon.className = 'fa fa-search';
      searchIcon.style.position = 'absolute';
      searchIcon.style.left = '10px';
      searchIcon.style.top = '50%';
      searchIcon.style.transform = 'translateY(-50%)';
      searchIcon.style.color = '#9ca3af';
      searchIcon.style.pointerEvents = 'none';

      searchWrapper.appendChild(searchInput);
      searchWrapper.appendChild(searchIcon);
      listContainer.appendChild(searchWrapper);

      const table = document.createElement('table');
      table.id = 'members-table';

      const thead = document.createElement('thead');
      thead.innerHTML = `
        <tr>
          <th>#</th>
          <th>Prénom</th>
          <th>Nom</th>
          <th>Cotisation (FCFA)</th>
          <th>Champ vide 1</th>
          <th>Champ vide 2</th>
        </tr>
      `;
      table.appendChild(thead);

      const tbody = document.createElement('tbody');

      function renderTable(data) {
        tbody.innerHTML = '';
        data.forEach((p, index) => {
          const tr = document.createElement('tr');
          tr.innerHTML = `<td>${index + 1}</td><td>${p.firstname || ''}</td><td>${p.lastname || ''}</td><td>${!isNaN(p.cotisation) ? Number(p.cotisation).toLocaleString('fr-FR') : ''}</td><td></td><td></td>`;
          tbody.appendChild(tr);
        });
      }

      renderTable(participants);
      table.appendChild(tbody);
      listContainer.appendChild(table);

      searchInput.addEventListener('input', () => {
        const term = searchInput.value.trim().toLowerCase();
        const filtered = participants.filter(p =>
          (p.firstname || '').toLowerCase().includes(term) ||
          (p.lastname || '').toLowerCase().includes(term) ||
          (!isNaN(p.cotisation) && p.cotisation.toString().includes(term))
        );
        renderTable(filtered);
      });
    }

    exportPdfBtn.addEventListener('click', () => {
      const participants = getStoredParticipants();
      if (!participants.length) return;

      const { jsPDF } = window.jspdf;
      const doc = new jsPDF();
      const now = new Date();
      const dateStr = now.toLocaleDateString('fr-FR');
      const dateTimeStr = now.toLocaleString('fr-FR');

      doc.setFontSize(18);
      doc.text('Membres de la tontine', 14, 20);
      doc.setFontSize(12);
      doc.text(`Exporté le : ${dateTimeStr}`, 14, 28);

      const lateMembers = participants.filter(p => p.isLate);
      if (lateMembers.length) {
        doc.setTextColor(255, 0, 0);
        const names = lateMembers.map(m => `${m.firstname} ${m.lastname}`).join(', ');
        doc.text(`⚠️ Retardataires : ${names}`, 14, 36);
      } else {
        doc.setTextColor(0, 128, 0);
        doc.text('✅ Formulaire de remplissage des mises par membres', 14, 36);
      }
      doc.setTextColor(0, 0, 0);

      const rows = participants.map((p, i) => [
        i + 1,
        p.firstname || '',
        p.lastname || '',
        !isNaN(p.cotisation) ? Number(p.cotisation).toLocaleString('fr-FR') : '',
        '',
        ''
      ]);

      const startY = lateMembers.length ? 44 : 40;
      doc.autoTable({
        startY,
        head: [['#', 'Nom', 'Prénom', 'Mise (FCFA)', 'Champ vide 1', 'Champ vide 2', 'Champ vide 3']],
        body: rows,
        theme: 'grid',
        headStyles: { fillColor: [37, 99, 235] },
        styles: { fontSize: 12 }
      });

      // QR Code simplifié
      const qrData = JSON.stringify({ website: "https://jonathanakoutabynarybridgestudio.netlify.app" });
      const tempDiv = document.createElement('div');
      new QRCode(tempDiv, { text: qrData, width: 80, height: 80, correctLevel: QRCode.CorrectLevel.H });
      const qrCanvas = tempDiv.querySelector('canvas');
      if (qrCanvas) {
        doc.addImage(qrCanvas.toDataURL('image/png'), 'PNG', doc.internal.pageSize.getWidth() - 50, doc.internal.pageSize.getHeight() - 50, 40, 40);
      }

      doc.setFontSize(10);
      doc.setTextColor(100);
      doc.text(`Développé par JONATHAN AKOUTA-BBStudio +228 98774038 – Généré le ${dateStr}`, 14, doc.internal.pageSize.getHeight() - 10);

      doc.save('membres_tontine.pdf');
    });

    openBtn.addEventListener('click', () => { displayMembers(); modalOverlay.style.display = 'flex'; });
    closeBtn.addEventListener('click', () => { modalOverlay.style.display = 'none'; });
    modalOverlay.addEventListener('click', e => { if (e.target === modalOverlay) modalOverlay.style.display = 'none'; });

    displayMembers();
  }
})();
