
(function(){
  const KEY = 'tontine_participants';

  function getParticipants(){ try{ return JSON.parse(localStorage.getItem(KEY)||'[]'); }catch{ return []; } }
  function saveParticipants(arr){ localStorage.setItem(KEY, JSON.stringify(arr)); }
  function genID(){ return 'MBR-' + Date.now().toString(36) + '-' + Math.floor(Math.random()*1e6).toString(36); }
  function ensureIDs(){
    let list = getParticipants(); let changed = false;
    list = list.map(p => { if(!p.id){ p.id = genID(); changed = true; } return p; });
    if(changed) saveParticipants(list);
  }

  /* ---------- UI: bouton flottant ---------- */
  function addFAB(){
    const btn = document.createElement('button');
    btn.className = 'tontine-fab tontine-font';
    btn.innerHTML = '<i class="fa-solid fa-qrcode"></i>&nbsp;IDF';
    btn.onclick = openModal;
    document.body.appendChild(btn);
  }

  /* ---------- UI: modale + grille ---------- */
  function openModal(){
    ensureIDs();
    let participants = getParticipants();

    const overlay = el('div','tontine-overlay tontine-font');
    const modal   = el('div','tontine-modal');

    const search  = el('input','tontine-search');
    search.placeholder = 'Rechercher par nom ou ID…';

    const exportBtn = el('button','tontine-btn pdf');
    exportBtn.innerHTML = '<i class="fa-solid fa-file-pdf"></i> Exporter PDF';
    exportBtn.onclick = () => exportPDF(participants);

    const closeBtn = el('button','tontine-btn close');
    closeBtn.innerHTML = '<i class="fa-solid fa-xmark"></i> Fermer';
    closeBtn.onclick = () => overlay.remove();

    const header = el('div','tontine-header', [search, exportBtn, closeBtn]);
    const grid   = el('div','tontine-grid');

    function render(filter=''){
      grid.innerHTML = '';
      participants
        .filter(p => {
          const full = `${p.firstname||''} ${p.lastname||''}`.trim().toLowerCase();
          const f = filter.toLowerCase();
          return full.includes(f) || (p.id||'').toLowerCase().includes(f);
        })
        .forEach(p => grid.appendChild(cardFor(p)));
    }

    search.addEventListener('input', e => render(e.target.value));

    modal.appendChild(header);
    modal.appendChild(grid);
    overlay.appendChild(modal);
    document.body.appendChild(overlay);

    render(); // initial
  }

  function cardFor(p){
    const card = el('div','tontine-card');
    const qrBox = el('div','tontine-qr');
    const qrEl = el('div'); qrBox.appendChild(qrEl);
    new QRCode(qrEl, { text: p.id, width: 120, height: 120 });

    const name = el('div','tontine-name'); name.textContent = `${p.firstname||''} ${p.lastname||''}`.trim();
    const id   = el('div','tontine-id');   id.textContent   = p.id;

    const copy = el('button','tontine-copy');
    copy.innerHTML = '<i class="fa-solid fa-copy"></i> Copier ID';
    copy.onclick = async () => {
      try { await navigator.clipboard.writeText(p.id); copy.innerHTML = '<i class="fa-solid fa-check"></i> Copié'; }
      catch { copy.innerHTML = '<i class="fa-solid fa-triangle-exclamation"></i> Erreur'; }
      setTimeout(()=> copy.innerHTML = '<i class="fa-solid fa-copy"></i> Copier ID', 1400);
    };

    card.append(qrBox, name, id, copy);
    return card;
  }

  /* ---------- PDF: grille multi-pages QR + nom + ID ---------- */
  async function exportPDF(participants){
    const { jsPDF } = window.jspdf;
    const doc = new jsPDF({ unit: 'mm', format: 'a4' });

    // Titre
    doc.setFontSize(16);
    doc.text('Catalogue des membres (QR)', doc.internal.pageSize.getWidth()/2, 15, { align: 'center' });

    // Layout
    const margin = { top: 22, right: 15, bottom: 18, left: 15 };
    const pageW = doc.internal.pageSize.getWidth();
    const pageH = doc.internal.pageSize.getHeight();
    const contentW = pageW - margin.left - margin.right;
    const contentH = pageH - margin.top - margin.bottom;

    const cellW = 60;         // largeur d'une carte
    const cellH = 58;         // hauteur d'une carte
    const qrSize = 32;        // taille du QR
    const gapY = 2;

    const cols = Math.max(1, Math.floor(contentW / cellW));       // nb colonnes selon la page
    const rows = Math.max(1, Math.floor(contentH / cellH));       // nb lignes selon la page
    const perPage = cols * rows;

    let x0 = margin.left + (contentW - cols*cellW)/2;             // centrage horizontal de la grille
    let y0 = margin.top;

    // Pré-générer images QR (base64) pour fluidité
    const qrImgs = [];
    for (const p of participants){
      const c = document.createElement('canvas');
      new QRCode(c, { text: p.id, width: 128, height: 128 });
      await wait(20);
      qrImgs.push(c.querySelector('img').src);
    }

    participants.forEach((p, i) => {
      const pageIndex = Math.floor(i / perPage);
      const indexInPage = i % perPage;
      const col = indexInPage % cols;
      const row = Math.floor(indexInPage / cols);

      if (indexInPage === 0 && i !== 0){ doc.addPage(); }

      const x = x0 + col * cellW;
      const y = y0 + row * cellH;

      // cadre léger
      doc.setDrawColor(230); doc.setLineWidth(0.2);
      doc.roundedRect(x+2, y+2, cellW-4, cellH-4, 2, 2);

      // QR centré
      const qrX = x + (cellW - qrSize)/2;
      const qrY = y + 6;
      doc.addImage(qrImgs[i], 'PNG', qrX, qrY, qrSize, qrSize);

      // Nom
      doc.setFontSize(10);
      const name = `${p.firstname||''} ${p.lastname||''}`.trim() || '—';
      doc.text(name, x + cellW/2, qrY + qrSize + 5, { align: 'center' });

      // ID — coupure propre (wrap) + centré
      doc.setFontSize(9);
      const idWidth = cellW - 8;
      const idLines = doc.splitTextToSize(p.id || '', idWidth);
      const idY = qrY + qrSize + 10;
      doc.text(idLines, x + cellW/2, idY, { align: 'center' });
    });

    doc.save('membres_qr_catalogue.pdf');
  }

  /* ---------- utils ---------- */
  function el(tag, cls, children){
    const n = document.createElement(tag);
    if(cls) n.className = cls;
    if(children) children.forEach(c => n.appendChild(c));
    return n;
  }
  const wait = (ms)=> new Promise(r=>setTimeout(r, ms));

  /* ---------- init ---------- */
  window.addEventListener('load', () => { ensureIDs(); addFAB(); });
})();
