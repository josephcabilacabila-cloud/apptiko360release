
(function(){
  const KEY = 'tontine_participants';

  // Tranches officielles
  const BRACKETS = [100, 200, 300, 500, 1000]; // 1000+ = dernière tranche

  // Définition par défaut des kits (modifiable dans l’UI)
  const DEFAULT_KITS = {
    "100":  "Riz 5kg; Huile 1L; Sucre 1kg",
    "200":  "Riz 10kg; Huile 2L; Sucre 2kg; Pâtes 2kg",
    "300":  "Riz 15kg; Huile 3L; Sucre 3kg; Pâtes 3kg; Haricots 2kg",
    "500":  "Riz 25kg; Huile 5L; Sucre 5kg; Pâtes 5kg; Haricots 3kg; Lait 2kg",
    "1000": "Riz 40kg; Huile 8L; Sucre 8kg; Pâtes 8kg; Haricots 5kg; Lait 4kg; Conserves 6"
  };

  function loadParticipants(){ try{ return JSON.parse(localStorage.getItem(KEY)||'[]'); }catch{ return []; } }
  function saveParticipants(arr){ localStorage.setItem(KEY, JSON.stringify(arr)); }
  function ensureIDs(){
    let list = loadParticipants(); let changed = false;
    list = list.map(p => { if(!p.id){ p.id = genID(); changed = true; } return p; });
    if(changed) saveParticipants(list);
  }
  function genID(){ return 'MBR-' + Date.now().toString(36) + '-' + Math.floor(Math.random()*1e6).toString(36); }

  function getAmount(p){
    // Essaie de lire un champ montant existant, sinon 0
    return Number(p.amount ?? p.montant ?? p.contribution ?? p.cotisation ?? 0) || 0;
  }
  function setAmount(p, val){
    p.amount = Number(val)||0;
  }

  function bracketOf(amount){
    if(amount>=1000) return 1000;
    if(amount>=500) return 500;
    if(amount>=300) return 300;
    if(amount>=200) return 200;
    if(amount>=100) return 100;
    return 0; // en-dessous de 100 (non classé)
  }

  // Charge/merge configs kits depuis localStorage (clé: kits_config)
  function loadKitsConfig(){
    const raw = localStorage.getItem('kits_config');
    let cfg = raw ? JSON.parse(raw) : {};
    return { ...DEFAULT_KITS, ...cfg };
  }
  function saveKitsConfig(cfg){
    localStorage.setItem('kits_config', JSON.stringify(cfg));
  }

  // FAB
  function addFAB(){
    const btn = document.createElement('button');
    btn.className = 'kits-fab kits-font';
    btn.innerHTML = '<i class="fa-solid fa-box-open"></i> Kits';
    btn.onclick = openModal;
    document.body.appendChild(btn);
  }

  function openModal(){
    ensureIDs();
    let participants = loadParticipants();
    let kitsCfg = loadKitsConfig();
    let activeBracket = 'ALL';
    let searchTerm = '';

    const overlay = div('kits-overlay kits-font');
    const modal   = div('kits-modal');

    const search  = input('kits-search','Rechercher par nom ou ID…');
    const btnAuto = button('kits-btn success','<i class="fa-solid fa-wand-magic-sparkles"></i> Assigner automatiquement');
    const btnClose= button('kits-btn muted','<i class="fa-solid fa-xmark"></i> Fermer');

    btnAuto.onclick = () => {
      participants.forEach(p=>{
        const amt = getAmount(p);
        const br = bracketOf(amt);
        if(br>0){
          p.kitBracket = br;
          p.kitName = 'Kit ' + br;
          p.kitItems = (kitsCfg[String(br)]||'').trim();
        }else{
          // en-dessous de 100 => rien
          delete p.kitBracket; delete p.kitName; delete p.kitItems;
        }
      });
      saveParticipants(participants);
      render();
      summary();


    };
    btnClose.onclick = () => overlay.remove();
    search.oninput = e => { searchTerm = e.target.value.toLowerCase(); render(); };

    const header = div('kits-header'); header.append(search, btnAuto, btnClose);

    // Onglets tranches
    const tabs = div('kits-tabs');
    const tabAll = tabBtn('Tous', 'ALL');
    tabs.appendChild(tabAll);
    [100,200,300,500,1000].forEach(b=>{
      tabs.appendChild(tabBtn(b.toString(), b));
    });

    function tabBtn(label, value){
      const t = div('kits-tab'); t.textContent = label;
      t.onclick = ()=>{ activeBracket = value; markActive(); render(); summary(); };
      t.dataset.value = value;
      return t;
    }
    function markActive(){
      [...tabs.children].forEach(ch=> ch.classList.toggle('active', String(ch.dataset.value)===String(activeBracket)));
    }
    markActive();

    // Panneau config kits
    const panel = div('kits-panel');
    const title = document.createElement('h4'); title.textContent = 'Configurer le contenu des kits (un item par “;”)';
    const area100 = ta('Kit 100', '100');
    const area200 = ta('Kit 200', '200');
    const area300 = ta('Kit 300', '300');
    const area500 = ta('Kit 500', '500');
    const area1000= ta('Kit 1000+', '1000');
    const btnSaveCfg = button('kits-btn primary','<i class="fa-solid fa-floppy-disk"></i> Enregistrer configuration');
    btnSaveCfg.onclick = ()=>{
      kitsCfg['100']  = area100.value.trim();
      kitsCfg['200']  = area200.value.trim();
      kitsCfg['300']  = area300.value.trim();
      kitsCfg['500']  = area500.value.trim();
      kitsCfg['1000'] = area1000.value.trim();
      saveKitsConfig(kitsCfg);
    };
    panel.append(title, area100.wrap, area200.wrap, area300.wrap, area500.wrap, area1000.wrap, btnSaveCfg);

    // grille
    const grid = div('kits-grid');

    // résumé
    const sumBox = div('kits-summary');

    function ta(label, key){
      const wrap = div();
      const h = document.createElement('div');
      h.innerHTML = `<strong>${label}</strong>`;
      const t = document.createElement('textarea');
      t.value = kitsCfg[String(key)]||'';
      wrap.append(h, t);
      return { wrap, value: t.value, get value(){ return t.value; }, set value(v){ t.value=v; } };
    }

    function render(){
      grid.innerHTML = '';
      const filt = String(activeBracket);
      const filtered = participants.filter(p=>{
        const full = `${p.firstname||''} ${p.lastname||''}`.trim().toLowerCase();
        const matchSearch = full.includes(searchTerm) || (p.id||'').toLowerCase().includes(searchTerm);
        const amt = getAmount(p);
        const br = bracketOf(amt);
        if(filt==='ALL') return matchSearch;
        return matchSearch && String(br)===filt;
      });

      filtered.forEach(p=>{
        grid.appendChild(cardFor(p));
      });
    }

    function cardFor(p){
      const card = div('kits-card');

      // QR
      const qrBox = div('kits-qr'); const qrEl = div(); qrBox.append(qrEl);
      new QRCode(qrEl, { text: p.id, width: 100, height: 100 });

      const right = div();

      const name = div('kits-name'); name.textContent = `${p.firstname||''} ${p.lastname||''}`.trim() || '—';
      const id = div('kits-id'); id.textContent = p.id || '—';

      const row1 = div('kits-row');
      const amtInput = document.createElement('input'); amtInput.className='kits-amount';
      amtInput.type='number'; amtInput.placeholder='Montant';
      amtInput.value = String(getAmount(p)||'');
      const br = bracketOf(getAmount(p));
      const tag = span('kits-tag', br>0 ? `Tranche ${br}` : 'Non classé');
      row1.append(amtInput, tag);

      const row2 = div('kits-row');
      const badge = span('kits-badge', p.kitName ? p.kitName : 'Aucun kit');
      const btnAssign = button('kits-btn primary','<i class="fa-solid fa-box"></i> Assigner');
      const btnClear  = button('kits-btn muted','<i class="fa-solid fa-eraser"></i> Retirer');
      row2.append(badge, btnAssign, btnClear);

      // events
      amtInput.onchange = ()=>{
        setAmount(p, amtInput.value);
        const nb = bracketOf(getAmount(p));
        tag.textContent = nb>0 ? `Tranche ${nb}` : 'Non classé';
        saveParticipants(updateOne(p));
        render(); summary();
      };
      btnAssign.onclick = ()=>{
        const b = bracketOf(getAmount(p));
        if(b>0){
          p.kitBracket = b;
          p.kitName = 'Kit ' + b;
          p.kitItems = (loadKitsConfig()[String(b)]||'').trim();
          saveParticipants(updateOne(p));
          badge.textContent = p.kitName;
          summary();
        }
      };
      btnClear.onclick = ()=>{
        delete p.kitBracket; delete p.kitName; delete p.kitItems;
        saveParticipants(updateOne(p));
        badge.textContent = 'Aucun kit';
        summary();
      };

      right.append(name, id, row1, row2);
      card.append(qrBox, right);
      return card;

      function updateOne(target){
        const arr = loadParticipants();
        const i = arr.findIndex(x=>x.id===target.id);
        if(i>-1) arr[i]=target;
        return arr;
      }
    }

    function summary(){
      // Résumé des quantités par tranche + compteur
      const data = { '100':0,'200':0,'300':0,'500':0,'1000':0 };
      const total = { members:0 };
      const itemsAgg = {}; // { 'Riz 5kg': 12, ... }
      loadParticipants().forEach(p=>{
        if(p.kitBracket){
          data[String(p.kitBracket)]++;
          total.members++;
          (p.kitItems||'').split(';').map(s=>s.trim()).filter(Boolean).forEach(it=>{
            itemsAgg[it] = (itemsAgg[it]||0)+1;
          });
        }
      });

      const parts = [];
      parts.push(`Affectés: <strong>${total.members}</strong> membres`);
      parts.push(`100: ${data['100']} • 200: ${data['200']} • 300: ${data['300']} • 500: ${data['500']} • 1000+: ${data['1000']}`);
      const lines = Object.entries(itemsAgg).map(([k,v]) => `${k}: ${v}`);
      sumBox.innerHTML = parts.join(' &nbsp;|&nbsp; ') + (lines.length ? `<br>Articles totaux → ${lines.join(' • ')}` : '');
    }

    modal.append(header, tabs, panel, grid, sumBox);
    overlay.appendChild(modal);
    document.body.appendChild(overlay);

    render(); summary();

    function div(cls){ const d=document.createElement('div'); if(cls) d.className=cls; return d; }
    function span(cls,txt){ const s=document.createElement('span'); if(cls) s.className=cls; s.innerHTML=txt; return s; }
    function input(cls,ph){ const i=document.createElement('input'); if(cls) i.className=cls; if(ph) i.placeholder=ph; return i; }
    function button(cls,html){ const b=document.createElement('button'); if(cls) b.className=cls; b.innerHTML=html; return b; }
  }

  window.addEventListener('load', ()=>{
    ensureIDs();
    addFAB();
  });
})();
