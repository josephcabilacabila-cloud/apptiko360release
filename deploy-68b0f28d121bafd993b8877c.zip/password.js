(() => {
  // ==== CONFIG ====
 // ==== MOT DE PASSE CACHÉ ====
const PASSWORD_ENCODED = "YnJpZGdlc3RlcA=="; // "bridge" encodé en Base64
function getPassword() {
  return atob(PASSWORD_ENCODED);
}

  const MAX_ATTEMPTS = 3;
  const LOCK_TIMES = [30, 60, 300, 900]; // en secondes
  const STORAGE_KEY = "modalLockerData"; // clé unique

  // ==== MULTI-LANGUE ====
  const LANGUAGES = {
    fr: {
      title: "Mot de passe requis",
      placeholder: "Tape ton mot de passe",
      accessBtn: "Accéder",
      incorrect: "❌ Mot de passe incorrect.",
      attemptsLeft: (n) => `Il te reste ${n} tentative${n > 1 ? "s" : ""}.`,
      lockedMsg: (t) => `⏳ Trop de tentatives. Réessaie dans ${t} seconde${t > 1 ? "s" : ""}.`,
      resetBtn: "Réinitialiser",
      showPwd: "Afficher mot de passe (3 sec)",
      hidePwd: "Masquer mot de passe",
      successMsg: "✅ Accès autorisé.",
      lockedTitle: "Accès temporairement bloqué",
    },
    en: {
      title: "Password required",
      placeholder: "Enter your password",
      accessBtn: "Access",
      incorrect: "❌ Incorrect password.",
      attemptsLeft: (n) => `You have ${n} attempt${n > 1 ? "s" : ""} left.`,
      lockedMsg: (t) => `⏳ Too many attempts. Try again in ${t} second${t > 1 ? "s" : ""}.`,
      resetBtn: "Reset",
      showPwd: "Show password (3 sec)",
      hidePwd: "Hide password",
      successMsg: "✅ Access granted.",
      lockedTitle: "Temporarily locked",
    }
  };

  // Détecte la langue du navigateur
  const userLang = (navigator.language || navigator.userLanguage || "fr").slice(0,2);
  const L = LANGUAGES[userLang] || LANGUAGES.fr;

  // ==== État sauvegardé ====
  let state = JSON.parse(localStorage.getItem(STORAGE_KEY)) || {
    attemptsLeft: MAX_ATTEMPTS,
    lockUntil: 0,
    lockLevel: 0,
  };

  function saveState() {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(state));
  }

  // ==== Styles ====
  const style = document.createElement("style");
  style.textContent = `
    @import url('https://fonts.googleapis.com/css2?family=Inter:wght@400;700&display=swap');
    #modal-locker-overlay {
      position: fixed; top: 0; left: 0; width: 100vw; height: 100vh;
      background-color: rgba(0,0,0,0.85);
      backdrop-filter: blur(6px);
      display: flex; justify-content: center; align-items: center;
      z-index: 99999; opacity: 0; animation: fadeIn 0.4s forwards;
      user-select: none;
    }
    @keyframes fadeIn { to { opacity: 1; } }
    #modal-locker-container {
      background: var(--bg,#fff); color: var(--text,#111);
      border-radius: 12px; width: 90%; max-width: 400px;
      padding: 32px 28px 40px; font-family: 'Inter', system-ui, sans-serif;
      box-shadow: 0 15px 50px rgba(0,0,0,0.4); display: flex; flex-direction: column; gap: 20px;
      outline: none; position: relative;
    }
    body[data-theme='dark'] #modal-locker-container { --bg:#121212; --text:#eee; }
    #modal-locker-container h2 { font-weight:700; font-size:1.8em; margin:0 0 12px 0; text-align:center; }
    #modal-locker-input { padding:14px 48px 14px 14px; font-size:1.1em; border:2px solid #ccc; border-radius:8px; outline:none; width:100%; transition:border-color 0.3s ease; box-sizing:border-box; caret-color:#10a37f; user-select:text; }
    #modal-locker-input:focus { border-color:#10a37f; box-shadow:0 0 10px #10a37f66; }
    #modal-locker-input.error { border-color:#e03e3e !important; animation: shake 0.3s; box-shadow:0 0 12px #e03e3e88 !important; }
    @keyframes shake {0%,100%{transform:translateX(0);}25%,75%{transform:translateX(-7px);}50%{transform:translateX(7px);}}
    #modal-locker-btn { background:#10a37f; color:white; font-weight:700; font-size:1.1em; padding:14px; border:none; border-radius:8px; cursor:pointer; transition:background-color 0.3s ease; user-select:none; }
    #modal-locker-btn:hover:not(:disabled) { background:#0e8d6e; }
    #modal-locker-btn:disabled { background:#888; cursor:not-allowed; }
    #modal-locker-error { color:#e03e3e; font-size:0.95em; min-height:1.3em; text-align:center; user-select:none; }
    #modal-locker-attempts { font-size:0.9em; color:#555; text-align:center; min-height:1.2em; user-select:none; }
    #modal-locker-toggle { position:absolute; right:14px; top:46px; background:none; border:none; cursor:pointer; font-size:1.2em; color:#777; user-select:none; outline-offset:2px; transition:color 0.3s ease; }
    #modal-locker-toggle:hover { color:#10a37f; }
    #modal-locker-toggle:focus { outline:2px solid #10a37f; outline-offset:2px; }
    #modal-locker-reset { margin-top:8px; background:#bbb; color:#333; font-size:0.9em; padding:10px 18px; border-radius:6px; border:none; cursor:pointer; align-self:center; user-select:none; transition: background-color 0.3s ease; }
    #modal-locker-reset:hover { background:#999; }
    @media (prefers-color-scheme: dark) { body:not([data-theme]) #modal-locker-container { --bg:#121212; --text:#eee; } }
  `;
  document.head.appendChild(style);

  // ==== Création HTML modale ====
  const modalHTML = `
    <div id="modal-locker-overlay" role="dialog" aria-modal="true" aria-labelledby="modal-locker-title" aria-describedby="modal-locker-error modal-locker-attempts">
      <div id="modal-locker-container" tabindex="0">
        <h2 id="modal-locker-title">${L.title}</h2>
        <div style="position:relative;">
          <input id="modal-locker-input" type="password" placeholder="${L.placeholder}" autocomplete="new-password" aria-invalid="false" aria-describedby="modal-locker-error modal-locker-attempts" />
          <button id="modal-locker-toggle" aria-label="${L.showPwd}" title="${L.showPwd}" type="button">👁️</button>
        </div>
        <button id="modal-locker-btn" aria-label="${L.accessBtn}">${L.accessBtn}</button>
        <p id="modal-locker-error" role="alert" aria-live="assertive"></p>
        <p id="modal-locker-attempts"></p>
        <button id="modal-locker-reset" type="button">${L.resetBtn}</button>
      </div>
    </div>
  `;

  const modalWrapper = document.createElement("div");
  modalWrapper.innerHTML = modalHTML;
  document.body.appendChild(modalWrapper);
  document.body.classList.add("modal-locked");
  document.body.style.overflow = "hidden";

  // ==== Références ====
  const modalOverlay = modalWrapper.querySelector("#modal-locker-overlay");
  const modalContainer = modalWrapper.querySelector("#modal-locker-container");
  const input = modalWrapper.querySelector("#modal-locker-input");
  const unlockBtn = modalWrapper.querySelector("#modal-locker-btn");
  const errorMsg = modalWrapper.querySelector("#modal-locker-error");
  const attemptsLeftEl = modalWrapper.querySelector("#modal-locker-attempts");
  const togglePasswordBtn = modalWrapper.querySelector("#modal-locker-toggle");
  const resetBtn = modalWrapper.querySelector("#modal-locker-reset");

  // ==== Fonctions ====
  let countdownInterval = null;

  function updateUI() {
    const now = Date.now();
    if (state.lockUntil && now < state.lockUntil) {
      const secondsLeft = Math.ceil((state.lockUntil - now) / 1000);
      errorMsg.textContent = L.lockedMsg(secondsLeft);
      attemptsLeftEl.textContent = "";
      input.disabled = true; unlockBtn.disabled = true; togglePasswordBtn.disabled = true;
      input.setAttribute("aria-invalid", "true");
      unlockBtn.setAttribute("aria-disabled", "true");
      startCountdown(secondsLeft);
    } else {
      state.lockUntil = 0; state.lockLevel = 0; input.disabled = false; unlockBtn.disabled = false; togglePasswordBtn.disabled = false;
      errorMsg.textContent = ""; attemptsLeftEl.textContent = L.attemptsLeft(state.attemptsLeft);
      input.setAttribute("aria-invalid", "false"); unlockBtn.removeAttribute("aria-disabled");
      stopCountdown(); saveState();
    }
  }

  function startCountdown(seconds) {
    stopCountdown();
    countdownInterval = setInterval(() => {
      const now = Date.now();
      if (now >= state.lockUntil) {
        state.attemptsLeft = MAX_ATTEMPTS; state.lockUntil = 0; state.lockLevel = 0;
        updateUI(); saveState(); clearInterval(countdownInterval); input.focus();
      } else {
        const secLeft = Math.ceil((state.lockUntil - now)/1000);
        errorMsg.textContent = L.lockedMsg(secLeft);
      }
    }, 1000);
  }

  function stopCountdown() { if(countdownInterval) clearInterval(countdownInterval); }

  function checkPassword() {
    if(input.disabled) return;
    const val = input.value.trim();
    if(!val) return;
   val === getPassword() ? success() : failAttempt();

  }

  function success() {
    errorMsg.style.color="#10a37f"; errorMsg.textContent=L.successMsg;
    input.classList.remove("error"); input.disabled=true; unlockBtn.disabled=true; togglePasswordBtn.disabled=true; resetBtn.disabled=true;
    modalOverlay.animate([{opacity:1},{opacity:0}],{duration:400}).onfinish=()=>{modalOverlay.remove(); document.body.classList.remove("modal-locked"); document.body.style.overflow="";}
    localStorage.removeItem(STORAGE_KEY);
  }

  function failAttempt() {
    state.attemptsLeft--;
    if(state.attemptsLeft<=0){ lock(); } 
    else{
      errorMsg.style.color="#e03e3e"; errorMsg.textContent=L.incorrect; input.classList.add("error"); 
      attemptsLeftEl.textContent=L.attemptsLeft(state.attemptsLeft); saveState(); 
      setTimeout(()=>input.classList.remove("error"),400);
    }
    input.value=""; input.focus();
  }

  function lock() {
    const nextLevel=Math.min(state.lockLevel+1,LOCK_TIMES.length-1);
    const lockTimeSec=LOCK_TIMES[nextLevel]; const now=Date.now();
    state.lockUntil=now+lockTimeSec*1000; state.lockLevel=nextLevel; state.attemptsLeft=0;
    saveState(); updateUI();
  }

  // Toggle mot de passe
  let toggleTimeout=null;
  togglePasswordBtn.addEventListener("click",()=>{
    if(input.type==="password"){
      input.type="text"; togglePasswordBtn.setAttribute("aria-label",L.hidePwd); togglePasswordBtn.title=L.hidePwd;
      toggleTimeout=setTimeout(()=>{input.type="password"; togglePasswordBtn.setAttribute("aria-label",L.showPwd); togglePasswordBtn.title=L.showPwd;},3000);
    }else{ input.type="password"; togglePasswordBtn.setAttribute("aria-label",L.showPwd); togglePasswordBtn.title=L.showPwd; clearTimeout(toggleTimeout);}
    input.focus();
  });

  resetBtn.addEventListener("click",()=>{
    state={attemptsLeft:MAX_ATTEMPTS, lockUntil:0, lockLevel:0};
    saveState(); updateUI(); input.value=""; input.focus(); errorMsg.textContent="";
  });

  unlockBtn.addEventListener("click", checkPassword);
  input.addEventListener("keydown", e => { if(e.key==="Enter"){ e.preventDefault(); checkPassword(); }});

  modalOverlay.addEventListener("click", e => { if(e.target===modalOverlay){ e.stopPropagation(); }});

  modalContainer.addEventListener("keydown", e=>{
    if(e.key==="Tab"){
      const focusable=modalContainer.querySelectorAll("button,input"); const first=focusable[0]; const last=focusable[focusable.length-1];
      if(e.shiftKey){ if(document.activeElement===first){ e.preventDefault(); last.focus(); } }
      else{ if(document.activeElement===last){ e.preventDefault(); first.focus(); } }
    }
  });

  window.addEventListener("wheel", e=>{ if(document.body.classList.contains("modal-locked")) e.preventDefault();},{passive:false});
  window.addEventListener("touchmove", e=>{ if(document.body.classList.contains("modal-locked")) e.preventDefault();},{passive:false});

  // Caps Lock warning
  const capsLockWarning=document.createElement('div');
  capsLockWarning.style.cssText='color:#e03e3e;font-size:0.9em;min-height:1.2em;text-align:center;user-select:none;margin-top:6px;';
  capsLockWarning.id='modal-locker-caps-warning';
  const inputParent=input.parentNode;
  inputParent.parentNode.insertBefore(capsLockWarning,inputParent.nextSibling);
  function updateCapsLockWarning(e){ capsLockWarning.textContent = e.getModifierState('CapsLock')?'⚠️ La touche Verr Maj est active':'';}
  input.addEventListener('keydown',updateCapsLockWarning);
  input.addEventListener('keyup',updateCapsLockWarning);

  // Initialisation
  updateUI();
  input.focus();
})();
