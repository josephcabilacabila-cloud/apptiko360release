
window.addEventListener("load", () => {
  const loader = document.getElementById("loader");
  const loaderText = document.getElementById("loader-text");
  const progressBar = document.getElementById("progress-bars");
  const progressPercent = document.getElementById("progress-percent");
  const stepsList = document.getElementById("steps-list");

 const steps = [
  { text: "Vérification de l'environnement système", progress: 10 },
  { text: "Chargement des modules nécessaires", progress: 20 },
  { text: "Initialisation des configurations et paramètres", progress: 30 },
  { text: "Chargement des données utilisateur", progress: 40 },
  { text: "Activation du service worker", progress: 50 },
  { text: "Chargement des bibliothèques et ressources externes (CDN)", progress: 60 },
  { text: "Établissement d'une connexion sécurisée", progress: 70 },
  { text: "Authentification et vérification des droits d'accès", progress: 80 },
  { text: "Synchronisation des données et cache local", progress: 90 },
  { text: "Finalisation du démarrage et préparation de l'interface", progress: 95 },
  { text: "Application prête à l'utilisation", progress: 100 },
];

  let stepIndex = 0;

  function addStepItem(text) {
    const li = document.createElement("li");
    li.style.marginBottom = "8px";
    li.innerHTML = `<i class="fas fa-spinner fa-spin" style="color:#00c6ff; margin-right:8px;"></i> ${text}`;
    stepsList.appendChild(li);
    return li;
  }

  function updateStepIcon(li) {
    li.innerHTML = `<i class="fas fa-check-circle" style="color:#00ff99; margin-right:8px;"></i> ${li.textContent}`;
  }

  function updateProgress(percent) {
    progressBar.style.width = percent + "%";
    progressPercent.textContent = percent + "%";
  }

  function nextStep() {
    if (stepIndex < steps.length) {
      loaderText.textContent = steps[stepIndex].text;
      updateProgress(steps[stepIndex].progress);
      
      const li = addStepItem(steps[stepIndex].text);
      setTimeout(() => updateStepIcon(li), 800);

      stepIndex++;
      setTimeout(nextStep, 1600);
    } else {
      loader.style.animation = "fadeOutScale 1s forwards ease";
      setTimeout(() => loader.remove(), 1000);
    }
  }

  setTimeout(nextStep, 500);
});
